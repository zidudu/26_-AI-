import copy
import json
import sqlite3
import threading

import pytest
from fastapi.testclient import TestClient

from arca_archive.db import Database, SCHEMA_VERSION
from arca_archive.fetch.ratelimit import RateLimiter
from arca_archive.pipeline.runner import CrawlContext, run_channel
from arca_archive.sites.base import ArticleParseError
from arca_archive.sites.dcinside import DCInsideSite
from arca_archive.web.app import create_app
from test_dcinside import ARTICLE, COMMENTS, LIST, result
from test_pipeline import FakeFetcher, make_factory
from test_web import DummyService


@pytest.fixture(autouse=True)
def no_wait(monkeypatch):
    monkeypatch.setattr(RateLimiter, 'wait', lambda self: None)


def dc_run(settings, db, responses, *, second_article=False, stop=None):
    ch = db.get_channel_by_slug('dc-test') or db.create_channel(
        'dc-test', site='dcinside', site_channel_id='aichatting', fetch_mode='http',
        initial_pages=1, recheck_days=0, collect_media=0)
    site = DCInsideSite()
    pages = {site.list_request(ch, 1).url: (200, LIST),
             site.article_request(ch, {'remote_id': '123'}).url: (200, ARTICLE)}
    if second_article:
        pages[site.list_request(ch, 1).url] = (200, LIST.replace('</table>',
            LIST[LIST.index('<tr'):LIST.index('</table>')].replace('123', '122') + '</table>'))
        pages[site.article_request(ch, {'remote_id': '122'}).url] = (200, ARTICLE.replace('value="123"', 'value="122"').replace('id="comment_cnt" value="2"', 'id="comment_cnt" value="0"'))

    class Mock(FakeFetcher):
        def fetch_form(self, url, data, headers):
            value = responses[int(data['comment_page']) - 1]
            if callable(value):
                value = value()
            if isinstance(value, int):
                return result('', url).__class__(url=url, status=value, html='', final_url=url)
            return result(json.dumps(value), url)

    run = run_channel(settings, db, ch['id'], stop_event=stop,
                      fetcher_factory=make_factory(Mock('http', pages), None))
    return run, site.internal_article_id(ch, '123'), ch


def test_zero_id_extra_row_reproduces_real_response_without_aborting(settings, db):
    payload = copy.deepcopy(COMMENTS)
    payload['comments'].append({'no': 0, 'parent': '', 'depth': 0, 'c_no': 0, 'memo': 'extra'})
    run, aid, _ = dc_run(settings, db, [payload], second_article=True)
    assert run['status'] == 'success' and run['stats']['collected'] == 2
    assert len(db.list_comments(aid)) == 2
    assert db.comment_fetch(aid)['state'] == 'complete'


@pytest.mark.parametrize('invalid', [None, [], {'no': '²'}, {'no': '-1'}, {'no': '1000000000000'},
    {'no': '503', 'memo': ['bad']}, {'no': '503', 'depth': 1, 'c_no': 'parent501'}])
def test_bad_row_keeps_valid_comments_and_next_article(settings, db, invalid):
    payload = copy.deepcopy(COMMENTS)
    payload['comments'].append(invalid)
    run, aid, _ = dc_run(settings, db, [payload], second_article=True)
    assert run['status'] == 'partial' and run['stats']['collected'] == 2
    assert len(db.list_comments(aid)) == 2
    assert db.comment_fetch(aid)['code'] == 'INVALID_ROWS'
    assert run['stats']['comments_incomplete'] == 1


@pytest.mark.parametrize('payload', [{'total_cnt': 2, 'comments': {}}, {'total_cnt': -1, 'comments': []},
                                     {'total_cnt': 'unknown', 'comments': []}])
def test_malformed_comment_envelope_is_explicit(payload):
    with pytest.raises(ArticleParseError):
        DCInsideSite().parse_comments(result(json.dumps(payload)))


def test_missing_html_count_is_unknown_and_still_checks_api(settings, db, monkeypatch):
    from arca_archive.sites.base import ArticleData
    for value in ('', 'unknown'):
        source = ARTICLE.replace('id="comment_cnt" value="2"', f'id="comment_cnt" value="{value}"')
        assert DCInsideSite().parse_article(result(source), {'remote_id': '123'}, {}, [], True).comment_count is None
    monkeypatch.setattr(DCInsideSite, 'parse_article', lambda *args: ArticleData(
        title='sample', body_html='<p>body</p>', body_text='body', body_hash='hash', comment_count=None))
    run, aid, _ = dc_run(settings, db, [COMMENTS])
    assert run['status'] == 'success' and len(db.list_comments(aid)) == 2
    assert db.comment_fetch(aid)['expected_count'] == 2


def test_second_page_failure_retries_old_article_without_resetting_body_or_bookmark(settings, db):
    first = {'total_cnt': 2, 'comments': COMMENTS['comments'][:1]}
    run, aid, ch = dc_run(settings, db, [first, 500])
    assert run['status'] == 'partial' and run['stats']['comments_saved'] == 1
    cf = db.comment_fetch(aid)
    assert (cf['state'], cf['saved_count'], cf['expected_count']) == ('incomplete', 1, 2)
    assert cf['next_retry_at'] and not db.comment_retry_candidates(ch['id'], 10)
    db.set_bookmark('article', aid, True)
    db.update_article(aid, created_at='2000-01-01T00:00:00+00:00')
    before = db.get_article(aid)
    assert db.requeue_comments(aid)
    assert db.get_article(aid) == before
    run2, _, _ = dc_run(settings, db, [COMMENTS])
    assert run2['status'] == 'success' and run2['stats']['rechecked'] == 1
    assert len(db.list_comments(aid)) == 2 and db.comment_fetch(aid)['state'] == 'complete'
    assert db.bookmarked_ids('article', [aid]) == {aid}
    assert not db.incomplete_comments()


def test_repeated_page_does_not_inflate_saved_count(settings, db):
    first = {'total_cnt': 2, 'comments': COMMENTS['comments'][:1]}
    run, aid, _ = dc_run(settings, db, [first, first])
    assert run['stats']['comments_saved'] == 1
    assert db.comment_fetch(aid)['code'] == 'NO_PROGRESS'
    assert db.comment_fetch(aid)['saved_count'] == 1


def test_page_limit_and_retry_cap_require_manual_reset(settings, db):
    settings.crawl.max_comment_pages_per_article = 1
    settings.retry.max_attempts = 1
    run, aid, ch = dc_run(settings, db, [{'total_cnt': 2, 'comments': COMMENTS['comments'][:1]}])
    assert db.comment_fetch(aid)['code'] == 'PAGE_LIMIT'
    assert db.comment_fetch(aid)['state'] == 'error'
    assert not db.comment_retry_candidates(ch['id'], 10)
    assert db.requeue_comments(aid)
    assert [a['id'] for a in db.comment_retry_candidates(ch['id'], 10)] == [aid]


@pytest.mark.parametrize('max_attempts', [1, 5])
def test_regular_recheck_respects_comment_retry_cap_and_backoff(settings, db, max_attempts):
    settings.retry.max_attempts = max_attempts
    _, aid, ch = dc_run(settings, db, [500])
    before = db.comment_fetch(aid)
    db.update_channel(ch['id'], recheck_days=30)
    settings.crawl.recheck_interval_hours = 0
    # 본문 재확인은 실행되지만 아직 재시도할 수 없는 댓글 API 호출은 없어야 합니다.
    run, _, _ = dc_run(settings, db, [])
    assert run['status'] == 'partial' and run['stats']['rechecked'] == 1
    assert db.comment_fetch(aid) == before
    assert any(e['event'] == 'comments_retry_deferred' for e in db.list_events(run['id']))


def test_raw_archive_failure_still_saves_comments(settings, db, monkeypatch):
    def fail(*args):
        raise OSError('disk test')
    monkeypatch.setattr('arca_archive.pipeline.comments.save_raw_text', fail)
    run, aid, _ = dc_run(settings, db, [COMMENTS])
    assert run['status'] == 'success' and len(db.list_comments(aid)) == 2
    assert db.comment_fetch(aid)['state'] == 'complete'
    assert any(e['event'] == 'raw_comments_save_failed' for e in db.list_events(run['id']))


def test_database_failure_does_not_claim_unsaved_comments_complete(settings, db, monkeypatch):
    original = db.replace_comments
    calls = []
    def fail_second(aid, rows):
        calls.append(aid)
        if len(calls) == 2:
            raise sqlite3.OperationalError('fixture storage failure')
        return original(aid, rows)
    monkeypatch.setattr(db, 'replace_comments', fail_second)
    run, aid, _ = dc_run(settings, db, [
        {'total_cnt': 2, 'comments': COMMENTS['comments'][:1]},
        {'total_cnt': 2, 'comments': COMMENTS['comments'][1:]},
    ])
    assert run['status'] == 'failed' and run['stats']['comments_saved'] == 1
    assert len(db.list_comments(aid)) == 1
    assert db.comment_fetch(aid)['state'] == 'pending'
    assert db.comment_fetch(aid)['saved_count'] == 1
    events = db.list_events(run['id'])
    assert not any(e['event'] == 'comments_collected' for e in events)
    assert next(e for e in events if e['event'] == 'run_aborted')['article_id'] == aid


def test_stop_preserves_partial_comments_for_retry(settings, db):
    stop = threading.Event()
    def first():
        stop.set()
        return {'total_cnt': 2, 'comments': COMMENTS['comments'][:1]}
    run, aid, _ = dc_run(settings, db, [first], stop=stop)
    assert run['status'] == 'cancelled'
    assert len(db.list_comments(aid)) == 1
    assert db.comment_fetch(aid)['code'] == 'INTERRUPTED'
    assert db.comment_fetch(aid)['attempts'] == 0


def test_access_denial_still_stops_run(settings, db):
    run, aid, _ = dc_run(settings, db, [403], second_article=True)
    assert run['status'] == 'failed' and run['code'] == 'FORBIDDEN'
    assert db.comment_fetch(aid)['state'] == 'incomplete'
    assert db.get_article(aid - 1)['state'] == 'discovered'


def test_time_budget_defers_without_using_failure_attempt(settings, db, monkeypatch):
    from arca_archive.pipeline.comments import collect_comment_pages
    ch = db.create_channel('sample', site='dcinside', site_channel_id='sample')
    db.upsert_discovered(ch['id'], [{'id': 1, 'url': 'https://example.com/1'}], None)
    ctx = CrawlContext(settings, db, db.create_run(ch, 'manual'), ch)
    monkeypatch.setattr(ctx, 'media_budget_exhausted', lambda: True)
    collect_comment_pages(ctx, db.get_article(1), result(ARTICLE), 2)
    cf = db.comment_fetch(1)
    assert cf['state'] == 'pending' and cf['code'] == 'TIME_BUDGET' and cf['attempts'] == 0
    assert ctx.stats.unfinished_after is None


def test_v6_migration_identifies_only_unverified_dc_comments_and_preserves_data(settings, db):
    dc = db.create_channel('dc-test', site='dcinside', site_channel_id='aichatting')
    arca = db.create_channel('arca-test')
    for aid, ch in ((1, dc), (2, dc), (3, arca)):
        db.upsert_discovered(ch['id'], [{'id': aid, 'url': f'https://example.com/{aid}'}], None)
        db.save_collected(aid, {'title': str(aid), 'body_hash': str(aid), 'comment_count': 1}, None, None)
    db.replace_comments(2, [{'id': 100, 'body_text': 'saved'}])
    db.set_bookmark('article', 1, True)
    con = db.connect()
    con.execute('DROP TABLE comment_fetches')
    con.execute('PRAGMA user_version=6')
    tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    before = {t: con.execute(f'SELECT * FROM {t} ORDER BY rowid').fetchall() for t in tables}
    db.close()
    upgraded = Database(settings.db_path)
    assert upgraded.connect().execute('PRAGMA user_version').fetchone()[0] == SCHEMA_VERSION
    assert [r['article_id'] for r in upgraded.incomplete_comments()] == [1]
    assert upgraded.comment_fetch(1)['code'] == 'LEGACY_UNVERIFIED'
    for t in tables:
        assert upgraded.connect().execute(f'SELECT * FROM {t} ORDER BY rowid').fetchall() == before[t]
    upgraded.close()
    again = Database(settings.db_path)
    assert len(again.incomplete_comments()) == 1
    assert not again.connect().execute('PRAGMA foreign_key_check').fetchall()
    again.close()


def test_comments_ui_retry_and_running_summary(settings, db):
    run, aid, _ = dc_run(settings, db, [500])
    body_before = db.get_article(aid)
    service = DummyService()
    with TestClient(create_app(settings, db, service)) as client:
        page = client.get('/errors')
        assert '댓글 확인 대기 / 미완료 (1)' in page.text and '댓글 재시도 예약' in page.text
        assert '일부 미완료' in client.get(f'/articles/{aid}').text
        response = client.post(f'/articles/{aid}/comments/retry', headers={'Referer': 'http://testserver/errors'}, follow_redirects=False)
        assert response.status_code == 303
        assert db.comment_fetch(aid)['code'] == 'RETRY_REQUESTED'
        assert db.get_article(aid) == body_before and not service.requests
        assert client.post('/articles/999/comments/retry').status_code == 404
        running = db.create_run(db.get_channel(body_before['channel_id']), 'manual')
        db.update_run(running['id'], stats={'unfinished_before': 99, 'unfinished_after': 0})
        page = client.get(f"/runs/{running['id']}")
        assert '종료 후 집계' in page.text and '종료 0개' not in page.text
        assert '다음 실행으로 이월' in client.get(f"/runs/{run['id']}").text
