"""네이버 카페 어댑터: 실제 캡처한 목록 API 응답과 합성 본문 JSON으로 검증합니다."""
from __future__ import annotations

import json

from arca_archive.db import Database
from arca_archive.fetch.base import FetchResult
from arca_archive.pipeline.runner import run_channel
from arca_archive.sites import get_site
from arca_archive.sites.naver_cafe import ID_SPACE, NaverCafeSite, strip_image_params
from conftest import read_fixture
from test_pipeline import JPG, FakeFetcher, make_factory

CAFE = "20179506"


def _channel(db: Database, **extra) -> dict:
    return db.create_channel("iroid", site="naver_cafe", site_channel_id=CAFE, name="클럽싼타페", initial_pages=1, **extra)


def _fr(text: str, status: int = 200, url: str = "https://x") -> FetchResult:
    return FetchResult(url=url, status=status, html=text, final_url=url, headers={}, fetcher="http")


def article_json(aid: int, content_html: str, comments: list | None = None, subject: str = "제목") -> str:
    return json.dumps({"result": {
        "cafeId": int(CAFE), "articleId": aid,
        "article": {"id": aid, "subject": subject, "writer": {"id": "w", "nick": "작성자", "memberLevelName": "성실멤버"},
                    "writeDate": 1789777867927, "readCount": 12, "commentCount": len(comments or []), "likeCount": 3,
                    "menu": {"id": 3365, "name": "싼타페 MX5 하이브리드"}, "contentHtml": content_html},
        "comments": {"items": comments or []},
    }}, ensure_ascii=False)


def test_channel_input_normalization():
    site = NaverCafeSite()
    calls = []

    def resolver(club=None, cafe_id=None):
        calls.append((club, cafe_id))
        return {"cafe_id": 20179506, "cafe_name": "클럽싼타페", "cafe_url": "iroid"}

    for text in ("iroid", "https://cafe.naver.com/iroid", "https://cafe.naver.com/iroid?iframe_url=/x"):
        info = site.normalize_channel_input(text, resolver=resolver)
        assert info == {"slug": "iroid", "name": "클럽싼타페", "site_channel_id": "20179506", "category": None}
    info = site.normalize_channel_input("https://cafe.naver.com/f-e/cafes/20179506/menus/3365?viewType=L", resolver=resolver)
    assert info["site_channel_id"] == "20179506" and info["category"] == "3365"
    assert calls[-1] == (None, "20179506")
    import pytest

    with pytest.raises(ValueError):
        site.normalize_channel_input("https://cafe.naver.com/f-e/", resolver=resolver)


def test_parse_real_list_fixture(db: Database):
    ch = _channel(db)
    site = get_site("naver_cafe")
    request = site.list_request(ch, 1)
    assert "cafes/20179506/menus/0/articles?page=1&pageSize=50" in request.url and request.kind == "json"
    page = site.parse_list(_fr(read_fixture("naver_list_page1.json")), ch)
    assert len(page.rows) == 50 and page.has_next is True
    ids = [int(r.remote_id) for r in page.rows]
    assert ids == sorted(ids, reverse=True)
    row = page.rows[0]
    assert row.url == f"https://cafe.naver.com/f-e/cafes/{CAFE}/articles/{row.remote_id}"
    assert row.title and row.author and row.created_at and row.created_at.endswith("+00:00")
    assert row.category and row.view_count is not None and row.comment_count is not None
    internal = site.internal_article_id(ch, row.remote_id)
    assert internal == ch["id"] * ID_SPACE + int(row.remote_id) and internal > 10 ** 12


def test_classify_login_deleted_restricted():
    site = get_site("naver_cafe")
    st = site.classify(_fr(read_fixture("naver_article_401.json"), status=401), "json")
    assert st.kind == "login_required" and st.stop
    st = site.classify(_fr(json.dumps({"result": {"errorCode": "0002", "reason": "삭제된 게시글입니다."}}), 200), "json")
    assert st.kind == "deleted" and not st.stop and not st.retryable
    st = site.classify(_fr(json.dumps({"result": {"errorCode": "0009", "reason": "등급이 부족하여 읽을 수 없습니다."}}), 200), "json")
    assert st.kind == "restricted" and not st.stop and not st.retryable
    assert site.classify(_fr("", 403), "json").kind == "restricted"
    assert site.classify(_fr("", 429), "json").stop
    assert site.classify(_fr(article_json(1, "<p>x</p>"), 200), "json").kind == "ok"


def test_parse_article_json_media_and_comments(db: Database):
    ch = _channel(db)
    site = get_site("naver_cafe")
    html = ('<div class="se-main-container"><p>첫 줄</p>'
            '<img src="https://cafeptthumb-phinf.pstatic.net/MjAy/abc/1280_x.jpg?type=w1600" width="800">'
            '<img src="https://cafeptthumb-phinf.pstatic.net/MjAy/abc/1280_x.jpg?type=w1600">'
            '<img src="https://cafeptthumb-phinf.pstatic.net/MjAy/def/photo.png?type=w966">'
            '<iframe src="https://www.youtube.com/embed/zzz"></iframe><script>evil()</script></div>')
    comments = [{"id": 111, "writer": {"nick": "댓글러"}, "content": "<p>좋아요</p>", "updateDate": 1789778000000},
                {"id": 112, "refId": 111, "writer": {"nick": "답글러"}, "content": "감사", "updateDate": 1789778100000, "isDeleted": False}]
    article = {"id": site.internal_article_id(ch, "5506282"), "remote_id": "5506282", "url": "u"}
    data = site.parse_article(_fr(article_json(5506282, html, comments)), article, ch, site.media_hosts(["ac.arca.live"]), True)
    assert data.title == "제목" and data.author == "작성자" and data.category == "싼타페 MX5 하이브리드"
    assert data.created_at == "2026-09-19T00:31:07+00:00" and data.view_count == 12 and data.like_count == 3
    assert "첫 줄" in data.body_text and "evil" not in data.body_html
    se = ('<div class="se-viewer"><!-- SE_DOC_HEADER_START --><!--@CONTENTS_HEADER--><div class="se-main-container">'
          '<div class="se-component se-text"><!-- SE-TEXT { --><p class="se-text-paragraph"><span>출석 도장 꾹~</span></p><!-- } SE-TEXT --></div></div></div>')
    plain = site.parse_article(_fr(article_json(5506282, se)), article, ch, [], False)
    assert plain.body_text == "출석 도장 꾹~" and "SE-TEXT" not in plain.body_html
    kinds = [m["kind"] for m in data.media]
    assert kinds == ["image", "image", "external"]  # 같은 이미지 중복 제거
    assert data.media[0]["original_url"] == "https://cafeptthumb-phinf.pstatic.net/MjAy/abc/1280_x.jpg"
    assert data.media[0]["url_expires_at"] is None
    assert [c["remote_id"] for c in data.comments] == ["111", "112"] and data.comments[1]["parent_remote_id"] == "111"
    assert data.comments[0]["body_text"] == "좋아요"
    assert strip_image_params("https://a.pstatic.net/x.jpg?type=w1600") == "https://a.pstatic.net/x.jpg"


def test_full_run_naver_channel_page_driven(settings, db: Database):
    """네이버는 처음부터 브라우저(페이지 주도): 목록은 페이지 내 fetch, 본문은 글 페이지를 열어 SPA의 API 응답을 가로챔.
    제한 글은 blocked, 삭제 글은 deleted, 세션 없이 API가 안 잡히면 LOGIN_REQUIRED."""
    ch = _channel(db)
    data = json.loads(read_fixture("naver_list_page1.json"))
    first = data["result"]["articleList"][:3]
    data["result"]["articleList"] = first
    small_list = json.dumps(data, ensure_ascii=False)
    a1, a2, a3 = (str(x["item"]["articleId"]) for x in first)
    list_url = f"https://apis.naver.com/cafe-web/cafe-boardlist-api/v1/cafes/{CAFE}/menus/0/articles?page=1&pageSize=50&sortBy=TIME&viewType=L"
    api = lambda aid: f"https://article.cafe.naver.com/gw/v4/cafes/{CAFE}/articles/{aid}?query=&useCafeId=true"
    img_html = '<p>본문</p><img src="https://cafeptthumb-phinf.pstatic.net/MjAy/q/pic.jpg?type=w1600">'
    browser = FakeFetcher("browser", {
        list_url: (200, small_list),
        api(a1): (200, article_json(int(a1), img_html, [{"id": 9, "writer": {"nick": "c"}, "content": "hi", "updateDate": 1789778000000}])),
        api(a2): (200, json.dumps({"result": {"errorCode": "0009", "reason": "등급이 부족하여 읽을 수 없습니다."}})),
        api(a3): (200, json.dumps({"result": {"errorCode": "0002", "reason": "삭제된 게시글입니다."}})),
    }, downloads={"https://cafeptthumb-phinf.pstatic.net/MjAy/q/pic.jpg": (200, JPG, "image/jpeg")})
    factory = make_factory(None, browser)
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=factory)
    st = run["stats"]
    assert run["status"] == "success", run
    assert factory.created == ["browser"]           # prefer_browser: HTTP 직접 호출 없음
    assert st["discovered_new"] == 3 and st["collected"] == 1 and st["blocked"] == 1 and st["deleted"] == 1 and st["failed"] == 0
    assert st["media_downloaded"] == 1 and st["comments_saved"] == 1
    # 글 페이지를 열었고(페이지 주도), API URL을 직접 부르지 않았다
    assert any(r == f"https://cafe.naver.com/f-e/cafes/{CAFE}/articles/{a1}" for r in browser.requests)
    assert not any(r.startswith("https://article.cafe.naver.com/") for r in browser.requests)
    site = get_site("naver_cafe")
    row = db.get_article(site.internal_article_id(ch, a1))
    assert row["state"] == "collected" and row["remote_id"] == a1 and row["raw_html_path"].endswith(".json.gz")
    assert db.get_article(site.internal_article_id(ch, a2))["state"] == "blocked"
    assert db.get_article(site.internal_article_id(ch, a3))["state"] == "deleted"
    media = db.list_media(row["id"])[0]
    assert media["state"] == "downloaded" and media["is_original"] == 1 and media["file_path"].endswith(".jpg")
    assert db.list_comments(row["id"])[0]["id"] == ch["id"] * ID_SPACE + 9
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(None, browser))
    assert run2["stats"]["discover_reason"] == "REACHED_KNOWN" and run2["stats"]["collect_targets"] == 0


def test_naver_page_without_api_and_no_session_is_login_required(settings, db: Database):
    ch = _channel(db)
    data = json.loads(read_fixture("naver_list_page1.json"))
    data["result"]["articleList"] = data["result"]["articleList"][:1]
    aid = str(data["result"]["articleList"][0]["item"]["articleId"])
    list_url = f"https://apis.naver.com/cafe-web/cafe-boardlist-api/v1/cafes/{CAFE}/menus/0/articles?page=1&pageSize=50&sortBy=TIME&viewType=L"
    page_url = f"https://cafe.naver.com/f-e/cafes/{CAFE}/articles/{aid}"
    browser = FakeFetcher("browser", {list_url: (200, json.dumps(data)), page_url: (200, "<html><body>카페홈 로그인</body></html>")})
    browser.session_flag = "0"
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(None, browser))
    assert run["status"] == "failed" and run["code"] == "LOGIN_REQUIRED"
    # 세션은 있는데 SPA가 API를 호출하지 않고 가입 안내만 보이면 blocked
    browser2 = FakeFetcher("browser", {list_url: (200, json.dumps(data)), page_url: (200, "<html><body>카페 가입 후 이용해 주세요</body></html>")})
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(None, browser2))
    assert run2["stats"]["blocked"] == 1 and run2["status"] == "success"


def test_naver_policy_is_conservative(settings, db: Database):
    from arca_archive.pipeline.runner import CrawlContext, initial_fetcher_kind

    ch = _channel(db)
    assert initial_fetcher_kind(ch) == "browser"
    run = db.create_run(ch, "manual")
    ctx = CrawlContext(settings, db, run, ch)
    assert ctx.page_limiter.min_interval >= 3.0 and ctx.page_limiter.jitter >= 2.0
    assert get_site("naver_cafe").policy.max_articles_per_run == 60
    req = get_site("naver_cafe").article_request(ch, {"remote_id": "5506305"})
    assert req.kind == "page_capture" and req.fallback.kind == "json"
    import re as _re
    assert _re.search(req.capture_pattern, f"https://article.cafe.naver.com/gw/v4/cafes/{CAFE}/articles/5506305?query=&useCafeId=true")
    assert not _re.search(req.capture_pattern, f"https://article.cafe.naver.com/gw/v4/cafes/{CAFE}/articles/55063050?query=")


def test_arca_and_naver_ids_do_not_collide(db: Database):
    arca = db.create_channel("ailove")
    naver = _channel(db)
    a = get_site("arca").internal_article_id(arca, "183424819")
    n = get_site("naver_cafe").internal_article_id(naver, "183424819")
    assert a == 183424819 and n != a and n // ID_SPACE == naver["id"]


def test_parse_real_public_article_fixture(db: Database):
    """실제 본문 API 응답(공개 게시판 글)으로 매핑과 스마트에디터 주석 제거를 확인합니다."""
    ch = _channel(db)
    site = get_site("naver_cafe")
    article = {"id": site.internal_article_id(ch, "5506305"), "remote_id": "5506305", "url": "u"}
    data = site.parse_article(_fr(read_fixture("naver_article_public.json")), article, ch, site.media_hosts([]), True)
    assert data.title == "출첵" and data.author and data.author_type == "새싹멤버" and data.category == "출석체크"
    assert data.created_at == "2026-09-19T00:42:29+00:00" and data.view_count == 0 and data.comment_count == 0
    assert data.body_text == "출석 도장 꾹~" and "SE-TEXT" not in data.body_html and "<!--" not in data.body_html
    assert data.media == [] and data.comments == [] and data.warnings == []
