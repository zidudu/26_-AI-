"""Do not mistake a successful original-URL request for original file content."""
import hashlib
from pathlib import Path
import pytest

from arca_archive.fetch.base import DownloadResult
from arca_archive.pipeline.media import _download_one, _upgrade_one, download_media_for_article
from arca_archive.pipeline.runner import CrawlContext
from arca_archive.media_integrity import original_format_mismatch
from scripts.repair_original_flags import apply_corrections, find_corrections
from test_db import _rows

MP4 = bytes.fromhex("000000206674797069736f6d") + b"\0" * 64
GIF = b"GIF89a" + b"\0" * 64


class ExactFetcher:
    def __init__(self, responses):
        self.responses, self.calls = responses, []

    def download(self, url, **kwargs):
        self.calls.append(url)
        status, data, content_type = self.responses[url]
        return DownloadResult(url, status, data, content_type)


def setup_media(settings, db):
    ch = db.create_channel("integrity")
    db.upsert_discovered(ch["id"], _rows(100), None)
    db.update_article(100, state="collected")
    media = db.upsert_media(100, [{"seq": 1, "kind": "gif", "source_key": "ac.arca.live/a.gif",
        "original_url": "https://ac-o.arca.live/a.gif?type=orig",
        "served_url": "https://ac.arca.live/a.mp4"}])[0]
    ctx = CrawlContext(settings, db, db.create_run(ch, "test"), ch)
    ctx.media_limiter.wait = lambda: 0
    ctx.original_limiter.wait = lambda: 0
    return ctx, db.get_article(100), media


def converted_responses(media):
    return {media["original_url"]: (403, b"denied", "application/xml"),
            media["served_url"] + "?type=orig": (200, MP4, "image/gif")}


def test_gif_denial_then_mp4_is_saved_once_as_converted_even_with_wrong_mime(settings, db):
    ctx, article, media = setup_media(settings, db)
    ctx.fetcher = ExactFetcher(converted_responses(media))
    assert _download_one(ctx, article, media)
    stored = db.get_media(media["id"])
    assert stored["is_original"] == 0
    assert Path(stored["file_path"]).read_bytes() == MP4
    assert stored["original_unavailable"] == 0  # format mismatch does not prove permanent absence
    assert stored["upgrade_attempts"] == 1
    assert stored["content_type"] == "video/mp4"
    assert len(ctx.fetcher.calls) == 2  # reuse the bytes, no duplicate served-URL download


def test_repeated_mp4_response_never_replaces_file_or_counts_as_upgrade(settings, db, tmp_path):
    ctx, article, media = setup_media(settings, db)
    old = tmp_path / "existing.mp4"
    old.write_bytes(MP4)
    db.update_media(media["id"], state="downloaded", is_original=0, file_path=str(old),
                    file_size=len(MP4), sha256=hashlib.sha256(MP4).hexdigest())
    ctx.fetcher = ExactFetcher(converted_responses(media))
    for _ in range(4):
        download_media_for_article(ctx, article)
    stored = db.get_media(media["id"])
    assert stored["is_original"] == 0 and stored["file_path"] == str(old)
    assert old.read_bytes() == MP4
    assert stored["upgrade_attempts"] == 3
    assert ctx.stats.media_upgraded == 0 and ctx.stats.media_downloaded == 0
    assert len(ctx.fetcher.calls) == 6  # the fourth run respects the existing retry cap


def test_real_gif_can_upgrade_after_a_format_mismatch(settings, db, tmp_path):
    ctx, article, media = setup_media(settings, db)
    old = tmp_path / "existing.mp4"
    old.write_bytes(MP4)
    db.update_media(media["id"], state="downloaded", is_original=0, file_path=str(old),
                    file_size=len(MP4), sha256=hashlib.sha256(MP4).hexdigest(), upgrade_attempts=1)
    ctx.fetcher = ExactFetcher({media["original_url"]: (200, GIF, "image/gif")})
    assert _upgrade_one(ctx, article, db.get_media(media["id"]))
    stored = db.get_media(media["id"])
    assert stored["is_original"] == 1 and Path(stored["file_path"]).read_bytes() == GIF
    assert ctx.stats.media_upgraded == 1
    assert stored["upgrade_attempts"] == 0


def test_failed_storage_is_not_reported_as_successful_upgrade(settings, db, monkeypatch):
    ctx, article, media = setup_media(settings, db)
    ctx.fetcher = ExactFetcher({media["original_url"]: (200, GIF, "image/gif")})
    monkeypatch.setattr("arca_archive.pipeline.media._store", lambda *args, **kwargs: False)
    assert not _upgrade_one(ctx, article, media)
    assert ctx.stats.media_upgraded == 0
    assert "media_upgraded" not in [e["event"] for e in db.list_events(ctx.run_id)]


@pytest.mark.parametrize("extension,data,mismatch", [
    ("gif", MP4, (".gif", ".mp4")),
    ("gif", GIF, None),
    ("png", b"RIFF\0\0\0\0WEBPVP8 ", (".png", ".webp")),
    ("jpeg", b"\xff\xd8\xff\xe0", None),
    ("avif", b"\0\0\0\x20ftypavif\0\0\0\0avif", None),
    ("mov", MP4, None),
    ("unknown", MP4, None),
    ("gif", b"not recognized", None),
])
def test_original_format_guard_is_conservative(extension, data, mismatch):
    assert original_format_mismatch({"original_url": f"https://test/a.{extension}"}, data) == mismatch


def test_metadata_repair_preserves_files_and_is_idempotent(settings, db, tmp_path):
    _, _, media = setup_media(settings, db)
    old = tmp_path / "wrongly-labelled.mp4"
    old.write_bytes(MP4)
    db.update_media(media["id"], state="downloaded", is_original=1, file_path=str(old),
                    file_size=len(MP4), sha256=hashlib.sha256(MP4).hexdigest(),
                    content_type="image/gif", original_unavailable=1, upgrade_attempts=3)
    stamp = old.stat().st_mtime_ns
    audit = find_corrections(settings.db_path)
    assert len(audit["corrections"]) == 1 and not audit["issues"]
    assert apply_corrections(settings.db_path, audit["corrections"]) == 1
    stored = db.get_media(media["id"])
    assert stored["state"] == "downloaded" and stored["is_original"] == 0
    assert stored["original_unavailable"] == 0 and stored["upgrade_attempts"] == 0
    assert stored["file_path"] == str(old) and old.read_bytes() == MP4 and old.stat().st_mtime_ns == stamp
    assert find_corrections(settings.db_path)["corrections"] == []


def test_metadata_repair_rolls_back_when_later_row_changed(settings, db, tmp_path):
    _, _, media = setup_media(settings, db)
    old = tmp_path / "a.mp4"
    old.write_bytes(MP4)
    db.update_media(media["id"], state="downloaded", is_original=1, file_path=str(old),
                    file_size=len(MP4), sha256=hashlib.sha256(MP4).hexdigest())
    rows = find_corrections(settings.db_path)["corrections"]
    # First update succeeds, but the absent second row must roll back the first.
    with pytest.raises(RuntimeError, match="Row changed"):
        apply_corrections(settings.db_path, rows + [{**rows[0], "id": 99999}])
    assert db.get_media(media["id"])["is_original"] == 1
    assert old.read_bytes() == MP4
