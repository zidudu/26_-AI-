from __future__ import annotations

import subprocess

from fastapi.testclient import TestClient

from arca_archive.cli import build_parser
from arca_archive.db import Database
from arca_archive.service import CrawlerService
from arca_archive.web.app import create_app


def test_login_command_line_is_parseable(settings, db: Database):
    """서버가 로그인 창을 띄울 때 만드는 명령이 CLI 파서에 통과해야 합니다."""
    service = CrawlerService(settings, db)
    captured: dict = {}

    class FakeProc:
        returncode = None

        def poll(self):
            return None

    def fake_popen(command, **kwargs):
        captured["command"] = command
        return FakeProc()

    original = subprocess.Popen
    subprocess.Popen = fake_popen  # type: ignore[assignment]
    try:
        result = service.open_login_window("https://arca.live/")
    finally:
        subprocess.Popen = original  # type: ignore[assignment]
    assert result["ok"], result
    argv = captured["command"][captured["command"].index("-m") + 2:]
    args = build_parser().parse_args(argv)
    assert args.command == "login" and args.url == "https://arca.live/" and str(args.config) == str(settings.config_path)
    assert service.login_window_open() is True


def test_login_window_immediate_exit_is_reported(settings, db: Database):
    service = CrawlerService(settings, db)

    class DeadProc:
        returncode = 2

        def poll(self):
            return 2

    original = subprocess.Popen
    subprocess.Popen = lambda *a, **k: DeadProc()  # type: ignore[assignment]
    try:
        result = service.open_login_window()
    finally:
        subprocess.Popen = original  # type: ignore[assignment]
    assert result["ok"] is False and "종료" in result["reason"]
    assert service.login_window_open() is False


def test_run_button_redirect_keeps_path_and_single_message(settings, db: Database):
    class DummyService:
        scheduler_enabled = True

        def start(self):
            pass

        def shutdown(self):
            pass

        def status(self):
            return {"running": False, "current": None, "run": None, "queue": [], "scheduler_enabled": True,
                    "login_window_open": False, "session": {"logged_in": None}, "last_error": None, "time": ""}

        def request_run(self, channel_id, trigger="manual"):
            return {"ok": True}

        def stop_current(self):
            return {"ok": True, "message": "stopped"}

    app = create_app(settings, db, DummyService())
    with TestClient(app) as client:
        ch = db.create_channel("x")
        r = client.post(f"/channels/{ch['id']}/run", headers={"referer": "http://127.0.0.1:8765/?m=%EC%9D%B4%EC%A0%84"},
                        follow_redirects=False)
        location = r.headers["location"]
        assert r.status_code == 303 and location.startswith("/?m=") and location.count("m=") == 1
        assert client.get(location).status_code == 200
        r = client.post(f"/channels/{ch['id']}/run", headers={"referer": f"http://127.0.0.1:8765/channels/{ch['id']}?m=a"},
                        follow_redirects=False)
        assert r.headers["location"].startswith(f"/channels/{ch['id']}?m=")
        assert client.get(r.headers["location"]).status_code == 200
        r = client.post("/stop", headers={"referer": "http://evil.example/x"}, follow_redirects=False)
        assert r.headers["location"].startswith("/x?m=")  # 외부 호스트는 버리고 경로만 사용


def test_login_window_lock_blocks_second_window(settings, db: Database):
    from arca_archive.common import AppError, RunLock
    from arca_archive.fetch.browser_fetcher import login_lock_path, login_window_locked, open_login_window
    import pytest

    assert login_window_locked(settings) is False
    holder = RunLock(login_lock_path(settings))
    assert holder.acquire()
    try:
        assert login_window_locked(settings) is True
        with pytest.raises(AppError) as exc:
            open_login_window(settings)
        assert exc.value.code == "LOGIN_WINDOW_OPEN"
        service = CrawlerService(settings, db)
        assert service.login_window_open() is True
        assert service.request_run(db.create_channel("y")["id"])["ok"] is False
    finally:
        holder.release()
    assert login_window_locked(settings) is False


def test_plain_browser_login_window_uses_profile_dir(settings, db: Database, tmp_path, monkeypatch):
    """로그인 창은 자동화 없이 일반 브라우저를 실행하고 전용 프로필 폴더를 넘겨야 합니다."""
    import sys
    from pathlib import Path
    from arca_archive.fetch import browser_fetcher as bf

    record = tmp_path / "args.txt"
    fake = tmp_path / "fake_browser.py"
    fake.write_text(
        "import sys, time, pathlib\n"
        "pathlib.Path(sys.argv[1]).write_text(chr(10).join(sys.argv[2:]), encoding='utf-8')\n"
        "time.sleep(2.5)\n",
        encoding="utf-8",
    )

    import subprocess
    original = subprocess.Popen

    def popen(command, **kwargs):
        assert command[0] == "FAKE"
        return original([sys.executable, str(fake), str(record), *command[1:]], **kwargs)

    monkeypatch.setattr(bf, "find_browser_executable", lambda s: "FAKE")
    monkeypatch.setattr(subprocess, "Popen", popen)
    assert bf.open_login_window(settings, "https://arca.live/u/login") == "closed"
    args = record.read_text(encoding="utf-8").splitlines()
    assert f"--user-data-dir={settings.profile_path}" in args
    assert "--enable-automation" not in " ".join(args) and "--remote-debugging" not in " ".join(args)
    assert args[-1] == "https://arca.live/u/login"
    assert bf.login_window_locked(settings) is False


def test_plain_browser_immediate_exit_means_profile_in_use(settings, db: Database, monkeypatch):
    import subprocess
    import sys
    import pytest
    from arca_archive.common import AppError
    from arca_archive.fetch import browser_fetcher as bf

    monkeypatch.setattr(bf, "find_browser_executable", lambda s: sys.executable)
    original = subprocess.Popen
    monkeypatch.setattr(subprocess, "Popen", lambda command, **k: original([sys.executable, "-c", "pass"], **k))
    with pytest.raises(AppError) as exc:
        bf.open_login_window(settings)
    assert exc.value.code == "BROWSER_PROFILE_IN_USE"


def test_find_browser_executable_does_not_crash(settings):
    from arca_archive.fetch.browser_fetcher import find_browser_executable

    result = find_browser_executable(settings)
    assert result is None or result.is_file()


def test_serve_detects_existing_server(settings, db: Database, monkeypatch, capsys):
    from arca_archive import cli

    monkeypatch.setattr(cli, "existing_server_status", lambda host, port: {"running": True, "scheduler_enabled": True,
                                                                             "current": {"channel_slug": "ailove", "run_id": 10}})
    import argparse

    code = cli.cmd_serve(argparse.Namespace(host=None, port=None), settings)
    out = capsys.readouterr().out
    assert code == 0 and "이미" in out and "ailove" in out
    monkeypatch.undo()
    assert cli.existing_server_status("127.0.0.1", 1) is None  # 닫힌 포트


def test_stop_current_sets_stopping_and_clears_queue(settings, db: Database):
    service = CrawlerService(settings, db)
    ch = db.create_channel("z")
    service.request_run(ch["id"])
    assert service.status()["queue"][0]["channel_slug"] == "z"
    result = service.stop_current()
    assert result["ok"] and service.status()["queue"] == []
    # 실행 중인 것처럼 상태를 만들고 중지 요청
    service.current = {"channel_id": ch["id"], "channel_slug": "z", "trigger": "manual", "started_at": "2026-01-01T00:00:00+00:00", "run_id": None}
    result = service.stop_current()
    status = service.status()
    assert status["stopping"] is True and status["running"] is True and service._stop_event.is_set()
    assert status["elapsed_seconds"] is not None and status["elapsed_seconds"] > 0
    assert "중지" in service.stop_current()["message"]


def test_paused_channel_is_skipped_by_scheduler_but_manual_run_allowed(settings, db: Database):
    service = CrawlerService(settings, db)
    ch = db.create_channel("paused", enabled=0)
    db.update_channel(ch["id"], next_run_at="2000-01-01T00:00:00+00:00")
    assert service._next_due() is None
    assert service.request_run(ch["id"])["ok"] is True
    service._queue.append((ch["id"], "schedule"))
    assert service.drop_scheduled(ch["id"]) == 1
    assert [t for _, t in service._queue] == ["manual"]
