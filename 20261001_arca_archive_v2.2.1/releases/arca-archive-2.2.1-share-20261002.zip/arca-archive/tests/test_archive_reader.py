from lxml import html as lxml_html
from fastapi.testclient import TestClient
from arca_archive.web.app import create_app
from arca_archive.web.reader import render_body
from test_db import _rows

def test_reader_strips_active_content_and_loads_only_local_media():
    html = '''<script>alert(1)</script><iframe src="https://bad.invalid"></iframe>
    <p onclick="bad()" style="background:url(https://bad.invalid)">본문</p>
    <img src="https://ac.arca.live/x.gif?expires=1" onerror="bad()">
    <img src="https://bad.invalid/tracker"><a href="javascript:bad()">링크</a><a href="/b/t/1">글</a>'''
    media = [{'state': 'downloaded', 'served_url': 'https://ac.arca.live/x.gif?expires=2', 'file_path': 'x.gif', 'content_type': 'image/gif', 'local_url': '/media/1/file'}]
    result = render_body(html, 'https://arca.live/b/t/1', media)
    soup = lxml_html.fromstring(result)
    assert not soup.xpath('.//script|.//iframe|.//video|.//*[@onclick or @onerror or @style]')
    assert soup.xpath('.//@src') == ['/media/1/file']
    assert not soup.xpath('.//a')[0].get('href')
    assert soup.xpath('.//a')[1].get('href') == 'https://arca.live/b/t/1'
    assert '미디어 미수집' in soup.text_content()

def test_search_scopes_literal_query_and_filters(settings, db):
    ch = db.create_channel('t')
    db.upsert_discovered(ch['id'], _rows(1, 2), None)
    db.update_article(1, title='100% literal', state='collected', created_at='2026-09-20T12:00:00+09:00')
    db.update_article(2, title='unrelated', state='collected', created_at='2026-09-21T12:00:00+09:00')
    db.replace_comments(2, [{'id': 100, 'body_text': '댓글 전용 검색', 'remote_id': '100'}])
    assert db.list_articles(query='%')[1] == 1
    assert db.list_articles(query='전용', scope='comments')[0][0]['id'] == 2
    assert db.list_articles(query='전용', scope='title')[1] == 0
    assert db.list_articles(date_to='2026-09-20')[1] == 1
    assert db.list_articles(site='naver_cafe')[1] == 0
    with TestClient(create_app(settings, db)) as client:
        for url in ['/backlog', '/api/backlog', '/articles?scope=comments&q=전용', '/articles/1']:
            assert client.get(url).status_code == 200
        assert client.get('/articles?date_from=bad').status_code == 400

def test_media_is_served_with_script_sandbox(settings,db):
    ch=db.create_channel('t')
    db.upsert_discovered(ch['id'],_rows(1),None)
    m=db.upsert_media(1,[{'seq':1,'kind':'image','source_key':'svg'}])[0]
    path=settings.media_path/'example.svg'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text('<svg xmlns="http://www.w3.org/2000/svg"></svg>')
    db.update_media(m['id'],state='downloaded',file_path=str(path),content_type='image/svg+xml')
    with TestClient(create_app(settings,db)) as client:
        for url in [f'/media/{m["id"]}/file','/media-files/example.svg']:
            response=client.get(url,headers={'Range':'bytes=0-3'})
            assert response.status_code==206
            assert 'sandbox' in response.headers['content-security-policy']
            assert response.headers['x-content-type-options']=='nosniff'

def test_actual_gif_uses_image_and_converted_mp4_uses_video(settings, db):
    ch = db.create_channel('t')
    db.upsert_discovered(ch['id'], _rows(1), None)
    rows = db.upsert_media(1, [{'seq': i, 'kind': 'gif', 'source_key': str(i)} for i in [1, 2]])
    for item, ext, ctype in [(rows[0], 'gif', 'image/gif'), (rows[1], 'mp4', 'video/mp4')]:
        db.update_media(item['id'], state='downloaded', file_path=str(settings.media_path/f"x.{ext}"), content_type=ctype)
    with TestClient(create_app(settings, db)) as client:
        for url in ['/media', '/articles/1']:
            soup = lxml_html.fromstring(client.get(url).text)
            assert soup.xpath('.//a[@data-kind="image"]/img[contains(@src,".gif")]')
            assert soup.xpath('.//a[@data-kind="video"]/video[contains(@src,".mp4")]')
