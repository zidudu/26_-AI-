from __future__ import annotations

from fastapi.testclient import TestClient

from arca_archive.common import AppError, iso_after
from arca_archive.db import Database
from arca_archive.pipeline.media import original_backoff_status, originals_allowed
from arca_archive.pipeline.runner import run_channel
from arca_archive.web.app import create_app
from test_pipeline import JPG, PNG, FakeFetcher, article_html, list_html, make_factory
from test_web import DummyService

WEBP = b"RIFF\x00\x00\x00\x00WEBPVP8 " + b"\x00" * 32


def _unreachable_originals(fetcher: FakeFetcher) -> FakeFetcher:
    original = fetcher.download

    def download(url, referer, max_bytes):
        if "type=orig" in url:
            fetcher.download_requests.append(url)
            raise AppError("NETWORK_ERROR", "connect timeout")
        return original(url, referer, max_bytes)

    fetcher.download = download  # type: ignore[assignment]
    return fetcher


def test_breaker_trips_after_repeated_connection_failures(settings, db: Database):
    slug = "cb"
    ch = db.create_channel(slug, initial_pages=1)
    ids = list(range(20, 10, -1))
    pages = {f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, ids))}
    downloads = {}
    for i in ids:
        pages[f"https://arca.live/b/{slug}/{i}"] = (200, article_html(slug, i, images=1))
        downloads[f"https://ac.arca.live/2026/{i}_0.png"] = (200, WEBP, "image/webp")
    http = _unreachable_originals(FakeFetcher("http", pages, downloads))
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    assert run["stats"]["media_downloaded"] == 10 and run["stats"]["media_failed"] == 0
    orig_attempts = [u for u in http.download_requests if "type=orig" in u]
    # 3회 연속 연결 실패 뒤에는 원본 요청을 건너뛴다(각 미디어마다 첫 원본 후보에서 즉시 중단)
    assert len(orig_attempts) == 3
    status = original_backoff_status(db)
    assert status["active"] and status["level"] == 1 and not originals_allowed(db)
    assert "ORIGINAL_ENDPOINT_DOWN" in run["stats"]["warnings"]
    media = db.list_media(20)[0]
    assert media["state"] == "downloaded" and media["is_original"] == 0 and media["upgrade_attempts"] == 0
    # 차단기가 켜진 동안에는 재확인이 승격 전용 대상을 열지 않는다
    http2 = _unreachable_originals(FakeFetcher("http", pages, downloads))
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http2, None))
    assert run2["stats"]["rechecked"] == 0
    # 차단 시간이 지나면 한 번 다시 시도하고, 성공하면 해제 + 승격
    db.set_setting("orig_backoff_until", iso_after(-1))
    downloads_ok = dict(downloads)
    for i in ids:
        downloads_ok[f"https://ac-o.arca.live/2026/{i}_0.png"] = (200, PNG, "image/png")
    http3 = FakeFetcher("http", pages, downloads_ok)
    run3 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http3, None))
    assert run3["stats"]["media_upgraded"] >= 1
    assert originals_allowed(db) and original_backoff_status(db)["level"] == 0
    assert db.list_media(20)[0]["is_original"] == 1


def test_breaker_backoff_grows_and_status_shown(settings, db: Database):
    slug = "cb2"
    ch = db.create_channel(slug, initial_pages=1)
    pages = {f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [3, 2, 1]))}
    downloads = {}
    for i in (1, 2, 3):
        pages[f"https://arca.live/b/{slug}/{i}"] = (200, article_html(slug, i, images=1))
        downloads[f"https://ac.arca.live/2026/{i}_0.png"] = (200, JPG, "image/jpeg")
    db.set_setting("orig_backoff_level", "2")
    run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(_unreachable_originals(FakeFetcher("http", pages, downloads)), None))
    assert original_backoff_status(db)["level"] == 3  # 2단계 → 120분 차단 후 다음 단계로
    service = DummyService()
    service.status = lambda: {**DummyService.status(service), "original_endpoint": original_backoff_status(db)}
    app = create_app(settings, db, service)
    with TestClient(app) as client:
        html = client.get("/").text
        assert "변환본만 받습니다" in html


def test_recheck_reserve_keeps_backlog_draining(settings, db: Database, monkeypatch):
    from arca_archive.pipeline import runner as runner_mod

    settings.media.run_time_budget_minutes = 1
    settings.media.recheck_reserve_minutes = 10
    slug = "rs"
    ch = db.create_channel(slug, initial_pages=1)
    pages = {f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [9])), f"https://arca.live/b/{slug}/9": (200, article_html(slug, 9, images=2))}
    downloads = {f"https://ac-o.arca.live/2026/9_{n}.png": (200, PNG, "image/png") for n in range(2)}
    clock = {"t": 1000.0}
    monkeypatch.setattr(runner_mod.time, "monotonic", lambda: clock["t"])
    http = FakeFetcher("http", pages, downloads)
    original = http.download

    def slow(url, referer, max_bytes):
        clock["t"] += 120  # 다운로드마다 2분 경과 → 1분 예산은 첫 파일에서 소진
        return original(url, referer, max_bytes)

    http.download = slow  # type: ignore[assignment]
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    assert run["stats"]["media_downloaded"] == 1 and run["stats"]["media_deferred"] == 1
    # 다음 실행: 수집 단계 예산이 없어도 재확인 단계는 보장 시간 동안 이월분을 처리한다
    http2 = FakeFetcher("http", pages, downloads)
    http2.download = slow  # type: ignore[assignment]
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http2, None))
    assert run2["stats"]["media_downloaded"] == 1 and db.count_media_by_state(ch["id"]) == {"downloaded": 2}


def test_media_cards_show_channel_and_extension_and_page_jump(settings, db: Database):
    app = create_app(settings, db, DummyService())
    with TestClient(app) as client:
        ch = db.create_channel("ext")
        db.upsert_discovered(ch["id"], [{"id": 5, "url": "https://arca.live/b/ext/5", "title": "t"}], None)
        db.save_collected(5, {"title": "t", "body_text": "b", "body_hash": "h"}, None, None)
        path = settings.media_path / "ext" / "5" / "01_abc.webp"
        path.parent.mkdir(parents=True)
        path.write_bytes(WEBP)
        db.upsert_media(5, [{"seq": 1, "kind": "image", "source_key": "ac.arca.live/a.png"},
                            {"seq": 2, "kind": "video", "source_key": "ac.arca.live/b.mp4"}])
        mid = db.list_media(5)[0]["id"]
        db.update_media(mid, state="downloaded", file_path=str(path), sha256="s", file_size=40, content_type="image/webp", is_original=0)
        html = client.get("/media?kind=image").text
        assert "<b>ext</b> · image · downloaded · 변환본 · webp" in html
        html = client.get("/media?state=pending").text
        assert "<b>ext</b> · video · pending · mp4" in html
        assert 'name="page" min="1"' in html and 'name="state" value="pending"' in html
        assert client.get("/media?state=pending&page=1").status_code == 200
        assert "· webp" in client.get("/articles/5").text
