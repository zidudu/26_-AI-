from __future__ import annotations

import base64
import hashlib
import sqlite3

import pytest
from fastapi.testclient import TestClient
from lxml import html

from arca_archive.db import Database, SCHEMA_VERSION
from arca_archive.web.app import create_app
from test_web import DummyService


@pytest.fixture
def saved_items(settings, db):
    first = db.create_channel("photos")
    second = db.create_channel("dcinside:sample", site="dcinside", site_channel_id="sample")
    for aid, cid, title in ((1, first["id"], "노을 100%_photo"), (2, first["id"], "텍스트 기록"), (3, second["id"], "산책 영상")):
        db.upsert_discovered(cid, [{"id": aid, "url": f"https://example.com/{aid}", "title": title}], None)
        db.save_collected(aid, {"title": title, "body_text": "바다 여행 기록", "author": "테스터", "body_hash": str(aid)}, None, None)
    image, gif, pending = db.upsert_media(1, [
        {"seq": 1, "kind": "image", "source_key": "first"},
        {"seq": 2, "kind": "gif", "source_key": "second"},
        {"seq": 3, "kind": "image", "source_key": "pending"},
    ])
    video = db.upsert_media(3, [{"seq": 1, "kind": "video", "source_key": "video"}])[0]
    path = settings.media_path / "pixel.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aP2kAAAAASUVORK5CYII="))
    for m in (image, gif):
        db.update_media(m["id"], state="downloaded", file_path=str(path), content_type="image/png", file_size=path.stat().st_size,
                        sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    return dict(channel=first, other_channel=second, image=image, gif=gif, pending=pending, video=video, path=path)


def test_bookmarks_are_independent_idempotent_and_persist(settings, db, saved_items):
    mid = saved_items["image"]["id"]
    before_articles = [tuple(r) for r in db.connect().execute("SELECT * FROM articles ORDER BY id")]
    before_media = [tuple(r) for r in db.connect().execute("SELECT * FROM media ORDER BY id")]
    before_bytes = saved_items["path"].read_bytes()
    db.set_bookmark("article", 1, True)
    db.set_bookmark("media", mid, True)
    initial = db.list_bookmarks()[0]
    db.set_bookmark("media", mid, True)
    assert db.list_bookmarks()[0] == initial  # 중복 저장은 정렬과 북마크 시각도 바꾸지 않음
    db.close()
    reopened = Database(settings.db_path)
    assert reopened.bookmarked_ids("article", [1, 2]) == {1}
    assert reopened.bookmarked_ids("media", [mid]) == {mid}
    reopened.set_bookmark("article", 1, False)
    reopened.set_bookmark("article", 1, False)
    assert reopened.list_bookmarks()[1] == 1
    assert reopened.bookmarked_ids("media", [mid]) == {mid}
    assert before_articles == [tuple(r) for r in reopened.connect().execute("SELECT * FROM articles ORDER BY id")]
    assert before_media == [tuple(r) for r in reopened.connect().execute("SELECT * FROM media ORDER BY id")]
    assert saved_items["path"].read_bytes() == before_bytes
    reopened.close()


def test_bookmarks_follow_media_refresh_but_never_start_downloads(db, saved_items):
    mid = saved_items["pending"]["id"]
    db.set_bookmark("media", mid, True)
    db.upsert_media(1, [{"seq": 8, "kind": "image", "source_key": "pending", "served_url": "https://example.com/new.png"}])
    row = db.list_bookmarks()[0][0]
    assert row["media_id"] == mid and row["state"] == "pending"
    assert row["file_path"] is None
    db.update_media(mid, state="downloaded", file_path=str(saved_items["path"]))
    assert db.list_bookmarks()[0][0]["file_path"] == str(saved_items["path"])
    assert db.bookmarked_ids("article", [1]) == set()


def test_bookmark_targets_and_foreign_keys(db, saved_items):
    for kind in ("article", "media"):
        with pytest.raises(LookupError):
            db.set_bookmark(kind, 999, True)
    with pytest.raises(ValueError):
        db.set_bookmark("unexpected", 1, True)
    with pytest.raises(sqlite3.IntegrityError):
        db.connect().execute("INSERT INTO bookmarks (created_at) VALUES ('x')")
    with pytest.raises(sqlite3.IntegrityError):
        db.connect().execute("INSERT INTO bookmarks (article_id,media_id,created_at) VALUES (1,?,'x')", (saved_items["image"]["id"],))
    db.set_bookmark("article", 1, True)
    db.set_bookmark("media", saved_items["image"]["id"], True)
    db.set_bookmark("article", 2, True)
    db.connect().execute("DELETE FROM articles WHERE id=1")
    assert [(r["bookmark_kind"], r["target_id"]) for r in db.list_bookmarks()[0]] == [("article", 2)]
    assert not db.connect().execute("PRAGMA foreign_key_check").fetchall()


def test_bookmark_filters_gallery_sort_and_literal_search(db, saved_items):
    for aid in (1, 2, 3):
        db.set_bookmark("article", aid, True)
    db.set_bookmark("media", saved_items["gif"]["id"], True)
    db.set_bookmark("media", saved_items["video"]["id"], True)
    rows, total = db.list_bookmarks()
    assert total == 7 and rows[0]["target_id"] == saved_items["video"]["id"]
    rows, total = db.list_bookmarks(kind="article", sort="oldest")
    assert total == 5 and [r["article_id"] for r in rows] == [1, 1, 1, 2, 3]
    assert rows[0]["media_id"] == saved_items["image"]["id"]
    assert rows[3]["media_id"] is None  # 이미지 없는 글도 그대로 표시
    rows, total = db.list_bookmarks(media_kind="gif")
    assert total == 2 and all(r["media_id"] == saved_items["gif"]["id"] for r in rows)
    assert db.list_bookmarks(channel_id=saved_items["other_channel"]["id"], media_kind="image")[1] == 0
    assert db.list_bookmarks(channel_id=saved_items["other_channel"]["id"], media_kind="video")[1] == 2
    assert db.list_bookmarks(query="100%_")[1] == 4
    assert db.list_bookmarks(query="%nonexistent_")[1] == 0
    assert db.list_bookmarks(query="바다", kind="article")[1] == 5
    assert db.list_bookmarks(query="테스터", kind="media")[1] == 2
    paged = db.list_bookmarks(sort="oldest", limit=2, offset=2)[0]
    assert [(r["bookmark_kind"], r["target_id"]) for r in paged] == [("article", 1), ("article", 2)]


def test_v5_migration_preserves_existing_data(settings, db, saved_items):
    original = {table: [tuple(row) for row in db.connect().execute(f"SELECT * FROM {table}")]
                for table in ("channels", "articles", "media", "comments")}
    # v5 파일을 재현한 뒤 새 Database 생성으로 실제 마이그레이션합니다.
    db.connect().execute("DROP TABLE bookmarks")
    db.connect().execute("PRAGMA user_version=5")
    db.close()
    upgraded = Database(settings.db_path)
    assert upgraded.connect().execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert upgraded.list_bookmarks()[1] == 0
    for table, rows in original.items():
        assert [tuple(row) for row in upgraded.connect().execute(f"SELECT * FROM {table}")] == rows
    upgraded.set_bookmark("article", 1, True)
    upgraded.close()
    again = Database(settings.db_path)
    assert again.bookmarked_ids("article", [1]) == {1}
    again.close()


def test_bookmark_api_validates_and_updates_all_page_states(settings, db, saved_items):
    mid = saved_items["image"]["id"]
    with TestClient(create_app(settings, db, DummyService())) as client:
        assert client.get("/bookmarks").status_code == 200
        assert "아직 북마크가 없습니다" in client.get("/bookmarks").text
        assert client.put("/api/bookmarks/article/1", json={"saved": "false"}).status_code == 422
        assert client.put("/api/bookmarks/article/999", json={"saved": True}).status_code == 404
        assert client.put("/api/bookmarks/invalid/1", json={"saved": True}).status_code == 422
        assert client.put("/api/bookmarks/article/1", data={"saved": "true"}).status_code == 422
        for kind, target in (("article", 1), ("media", mid)):
            r = client.put(f"/api/bookmarks/{kind}/{target}", json={"saved": True})
            assert r.status_code == 200 and r.json()["saved"] is True
        for path in ("/articles", "/articles/1", "/media", "/bookmarks"):
            tree = html.fromstring(client.get(path).text)
            article_buttons = tree.xpath('//button[@data-bookmark-kind="article"][@data-bookmark-id="1"]')
            assert article_buttons and all(b.get("aria-pressed") == "true" for b in article_buttons)
            if path != "/articles":
                assert tree.xpath(f'//button[@data-bookmark-kind="media"][@data-bookmark-id="{mid}"][@aria-pressed="true"]')
                assert tree.xpath(f'//a[@data-viewer][@data-media-id="{mid}"][@data-article-id="1"]')
        assert client.put(f"/api/bookmarks/media/{mid}", json={"saved": False}).json()["saved"] is False
        tree = html.fromstring(client.get("/bookmarks").text)
        assert len(tree.xpath('//article[@data-saved-kind="article"]')) == 3
        assert not tree.xpath('//article[@data-saved-kind="media"]')


def test_bookmark_page_missing_files_and_escaped_content(settings, db, saved_items):
    db.update_article(2, title='<script>alert("x")</script>', body_text='<img src=x onerror=alert(1)>')
    db.set_bookmark("article", 2, True)
    db.set_bookmark("media", saved_items["image"]["id"], True)
    saved_items["path"].unlink()
    with TestClient(create_app(settings, db, DummyService())) as client:
        tree = html.fromstring(client.get("/bookmarks").text)
        assert not tree.xpath('//section[@id="bookmark-results"]//script | //section[@id="bookmark-results"]//img')
        assert "텍스트 글" in tree.text_content() and "파일 없음" in tree.text_content()
        for url in ("/bookmarks?kind=bad&channel_id=abc&media_kind=bad&sort=bad&page=abc", "/bookmarks?page=-2"):
            assert client.get(url).status_code == 200


def test_bookmark_pagination_retains_combined_filters(settings, db, saved_items):
    cid = saved_items["channel"]["id"]
    db.upsert_discovered(cid, [{"id": i, "url": f"https://example.com/{i}", "title": "필터 대상"} for i in range(10, 75)], None)
    for aid in range(10, 75):
        db.set_bookmark("article", aid, True)
    with TestClient(create_app(settings, db, DummyService())) as client:
        r = client.get("/bookmarks", params={"kind": "article", "channel_id": cid, "q": "필터", "sort": "oldest", "page": 99})
        tree = html.fromstring(r.text)
        assert "65개 · 2/2 페이지" in tree.text_content()
        assert len(tree.xpath('//article[@data-saved-kind]')) == 5
        href = tree.xpath('//nav[@aria-label="북마크 페이지 이동"]/a/@href')[0]
        from urllib.parse import parse_qs, urlsplit
        assert parse_qs(urlsplit(href).query) == {"kind": ["article"], "channel_id": [str(cid)], "q": ["필터"], "sort": ["oldest"]}


def test_article_gallery_pages_every_media_in_body_order(settings, db, saved_items):
    db.upsert_media(1, [{"seq": seq, "kind": "image", "source_key": f"extra-{seq}"} for seq in range(4, 66)])
    db.upsert_media(1, [{"seq": 66, "kind": "image", "origin": "comment", "source_key": "comment-image"}])
    db.set_bookmark("article", 1, True)
    body_media = [m for m in db.list_media(1) if m["origin"] == "body"]
    expected_ids = [m["id"] for m in body_media]
    first, total = db.list_bookmarks(kind="article", limit=60)
    second, _ = db.list_bookmarks(kind="article", limit=60, offset=60)
    assert total == 65 and len(first) == 60 and len(second) == 5
    assert [m["media_id"] for m in first + second] == expected_ids
    # 조회는 글 북마크를 각 이미지의 별도 북마크로 복제하지 않습니다.
    assert db.connect().execute("SELECT COUNT(*) FROM bookmarks").fetchone()[0] == 1
    assert not db.bookmarked_ids("media", expected_ids)
    with TestClient(create_app(settings, db, DummyService())) as client:
        first_tree = html.fromstring(client.get("/bookmarks?kind=article").text)
        second_tree = html.fromstring(client.get("/bookmarks?kind=article&page=2").text)
        assert "표시 항목 65개 · 2/2 페이지" in second_tree.text_content()
        selector = '//article[@data-saved-kind="article"]//button[@data-bookmark-kind="media"]/@data-bookmark-id'
        assert [int(mid) for mid in first_tree.xpath(selector) + second_tree.xpath(selector)] == expected_ids
        assert client.get("/bookmarks?kind=article&page=999").text == client.get("/bookmarks?kind=article&page=2").text


def test_article_gallery_filters_and_removal_keep_individual_bookmarks(settings, db, saved_items):
    db.set_bookmark("article", 1, True)
    db.set_bookmark("media", saved_items["gif"]["id"], True)
    before = saved_items["path"].read_bytes()
    with TestClient(create_app(settings, db, DummyService())) as client:
        tree = html.fromstring(client.get("/bookmarks?kind=article&media_kind=image").text)
        ids = tree.xpath('//article//button[@data-bookmark-kind="media"]/@data-bookmark-id')
        assert list(map(int, ids)) == [saved_items["image"]["id"], saved_items["pending"]["id"]]
        assert not tree.xpath('//article[@data-saved-kind="media"]')
        # 북마크 이후 본문에 발견된 이미지도 바로 포함됩니다.
        db.upsert_media(1, [{"seq": 4, "kind": "image", "source_key": "newly-collected"}])
        assert db.list_bookmarks(kind="article", media_kind="image")[1] == 3
        assert client.put("/api/bookmarks/article/1", json={"saved": False}).status_code == 200
        rows, total = db.list_bookmarks()
        assert total == 1 and rows[0]["bookmark_kind"] == "media"
        assert rows[0]["media_id"] == saved_items["gif"]["id"]
        assert saved_items["path"].read_bytes() == before
