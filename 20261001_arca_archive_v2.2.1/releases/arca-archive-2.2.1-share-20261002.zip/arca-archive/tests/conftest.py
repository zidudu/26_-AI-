from __future__ import annotations

import json
from pathlib import Path

import pytest

from arca_archive.config import Settings, load_settings
from arca_archive.db import Database

FIXTURES = Path(__file__).parent / "fixtures"


def read_fixture(name: str) -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    config_path = tmp_path / "config" / "settings.json"
    config_path.parent.mkdir(parents=True)
    data = Settings().model_dump()
    data["data_dir"] = "data"
    data["http"]["page_delay_seconds"] = 0.5
    data["http"]["page_delay_jitter_seconds"] = 0
    data["http"]["media_delay_seconds"] = 0
    data["seed_channels"] = []
    config_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    s = load_settings(config_path)
    # 테스트에서는 대기 없이 진행합니다.
    s.http.page_delay_seconds = 0.5
    return s


@pytest.fixture
def db(settings: Settings) -> Database:
    database = Database(settings.db_path)
    yield database
    database.close()
