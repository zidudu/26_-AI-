from __future__ import annotations

from arca_archive.config import RetrySettings
from arca_archive.fetch.ratelimit import RateLimiter
from arca_archive.pipeline.retry import retry_delay_seconds, schedule_retry


def test_backoff_and_cap():
    policy = RetrySettings(max_attempts=4, base_delay_minutes=10, max_delay_minutes=60)
    assert retry_delay_seconds(1, policy) == 600
    assert retry_delay_seconds(2, policy) == 1200
    assert retry_delay_seconds(3, policy) == 2400
    assert retry_delay_seconds(4, policy) == 3600
    assert retry_delay_seconds(9, policy) == 3600


def test_schedule_retry_states():
    policy = RetrySettings(max_attempts=2, base_delay_minutes=1, max_delay_minutes=5)
    state, when = schedule_retry(1, policy)
    assert state == "failed" and when
    assert schedule_retry(2, policy) == ("error", None)


def test_rate_limiter_waits():
    slept: list[float] = []
    clock = {"t": 0.0}

    def sleep(s):
        slept.append(s)
        clock["t"] += s

    limiter = RateLimiter(2.0, 0, sleep=sleep, clock=lambda: clock["t"])
    assert limiter.wait() == 0
    clock["t"] += 0.5
    waited = limiter.wait()
    assert 1.4 < waited <= 1.5
    assert slept and abs(slept[0] - waited) < 1e-9


def test_rate_limiter_interrupt_returns_immediately():
    import threading

    stop = threading.Event()
    clock = {"t": 0.0}
    limiter = RateLimiter(5.0, 0, clock=lambda: clock["t"], interrupt=stop)
    limiter.wait()
    stop.set()
    started = __import__("time").monotonic()
    limiter.wait()  # 5초 대기 대신 즉시 반환
    assert __import__("time").monotonic() - started < 1.0
