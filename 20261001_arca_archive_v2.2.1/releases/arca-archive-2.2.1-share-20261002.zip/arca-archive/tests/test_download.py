from __future__ import annotations

import threading

import httpx
import pytest

from arca_archive.common import AppError
from arca_archive.fetch.download import stream_download


def _client(chunks: list[bytes], on_chunk=None, status: int = 200, headers: dict | None = None) -> httpx.Client:
    def handler(request: httpx.Request) -> httpx.Response:
        def gen():
            for c in chunks:
                if on_chunk:
                    on_chunk()
                yield c
        return httpx.Response(status, headers=headers or {"content-type": "image/png"}, stream=httpx.ByteStream(b"".join(chunks)) if on_chunk is None else _IterStream(gen()))
    return httpx.Client(transport=httpx.MockTransport(handler))


class _IterStream(httpx.SyncByteStream):
    def __init__(self, it):
        self._it = it

    def __iter__(self):
        yield from self._it


def test_stream_download_ok():
    client = _client([b"\x89PNG", b"rest"])
    result = stream_download(client, "https://ac.arca.live/x.png?expires=1&key=k", "https://arca.live/", 10_000)
    assert result.ok and result.data == b"\x89PNGrest" and result.content_type == "image/png"


def test_stream_download_stops_between_chunks():
    stop = threading.Event()
    seen = {"n": 0}

    def on_chunk():
        seen["n"] += 1
        if seen["n"] == 2:
            stop.set()

    client = _client([b"a" * 10, b"b" * 10, b"c" * 10], on_chunk=on_chunk)
    with pytest.raises(AppError) as exc:
        stream_download(client, "https://ac.arca.live/big.mp4", "https://arca.live/", 10_000, stop_event=stop)
    assert exc.value.code == "STOPPED"
    assert seen["n"] <= 3


def test_stream_download_too_large():
    client = _client([b"a" * 100], headers={"content-type": "image/png", "content-length": "100"})
    with pytest.raises(AppError) as exc:
        stream_download(client, "https://ac.arca.live/x.png", "https://arca.live/", 50)
    assert exc.value.code == "MEDIA_TOO_LARGE" and exc.value.retryable is False
