"""Recovery work must make progress even with newer posts and media queued."""
from arca_archive.service import CrawlerService
from arca_archive.pipeline.runner import run_channel
from test_db import _rows
from test_pipeline import FakeFetcher, PNG, article_html, list_html, make_factory


PAST = "2000-01-01T00:00:00+00:00"
FUTURE = "2999-01-01T00:00:00+00:00"


def test_scheduler_selects_longest_overdue_channel(settings, db):
    service = CrawlerService(settings, db)
    newer = db.create_channel("newer")
    oldest = db.create_channel("oldest")
    paused = db.create_channel("paused", enabled=0)
    future = db.create_channel("future")
    db.update_channel(newer["id"], next_run_at="2001-01-01T00:00:00+00:00")
    db.update_channel(oldest["id"], next_run_at=PAST)
    db.update_channel(paused["id"], next_run_at="1999-01-01T00:00:00+00:00")
    db.update_channel(future["id"], next_run_at=FUTURE)
    assert service._next_due() == (oldest["id"], "schedule")
    assert service.status()["next_due"]["channel_slug"] == "oldest"
    db.update_channel(oldest["id"], next_run_at=FUTURE)
    assert service._next_due() == (newer["id"], "schedule")
    db.update_channel(newer["id"], next_run_at=FUTURE)
    assert service._next_due() is None


def test_due_retries_have_reserved_slots_without_blocking_new_posts(db):
    ch = db.create_channel("t")
    db.upsert_discovered(ch["id"], _rows(*range(1, 21)), None)
    for aid in range(1, 9):
        db.mark_article_failure(aid, "failed", "SERVER_ERROR", "504", PAST, attempts=1)
    db.mark_article_failure(9, "failed", "NETWORK_TIMEOUT", "timeout", FUTURE, attempts=1)
    db.mark_article_failure(10, "error", "PARSE", "exhausted", None, attempts=4)
    db.mark_article_failure(11, "blocked", "RESTRICTED", "restricted", None)
    batch = db.pending_articles(ch["id"], 5)
    assert batch[0]["state"] == "failed"
    assert [a["id"] for a in batch[1:]] == [20, 19, 18, 17]
    assert len({a["id"] for a in batch}) == 5
    assert not {9, 10, 11}.intersection(a["id"] for a in batch)
    # Unused new-post slots may be filled by remaining eligible retries.
    assert len(db.pending_articles(ch["id"], 30)) == 17
    assert db.pending_articles(ch["id"], 0) == []


def test_manual_requeue_keeps_recovery_priority(db):
    ch = db.create_channel("t")
    db.upsert_discovered(ch["id"], _rows(*range(1, 11)), None)
    db.mark_article_failure(1, "error", "NETWORK_ERROR", "exhausted", None, attempts=4)
    assert db.requeue_articles(ch["id"]) == 1
    assert db.pending_articles(ch["id"], 5)[0]["id"] == 1
    for aid in [2, 10]:
        db.update_article(aid, state="collected")
        item = db.upsert_media(aid, [{"seq": 1, "kind": "image", "source_key": str(aid)}])[0]
        if aid == 2:
            db.update_media(item["id"], state="error", attempts=4)
    assert db.requeue_media(2) == 1
    assert db.expired_media_articles(ch["id"], 1)[0]["id"] == 2


def test_media_recovery_precedes_new_pending_and_original_upgrades(db):
    ch = db.create_channel("t")
    db.upsert_discovered(ch["id"], _rows(1, 2, 3, 4, 5, 6), None)
    for aid, state in [(1, "expired"), (2, "failed"), (3, "pending"),
                       (4, "downloaded"), (5, "failed"), (6, "error")]:
        db.update_article(aid, state="collected", last_checked_at=PAST)
        m = db.upsert_media(aid, [{"seq": 1, "kind": "image", "source_key": f"media/{aid}",
                                  "original_url": f"https://ac.arca.live/{aid}?type=orig"}])[0]
        db.update_media(m["id"], state=state, is_original=0,
                        next_retry_at=FUTURE if aid == 5 else None)
    rows = db.expired_media_articles(ch["id"], 4)
    assert {a["id"] for a in rows[:2]} == {1, 2}
    assert [a["id"] for a in rows[2:]] == [3, 4]
    # Refreshing one recovery item lets the older recovery item go first next time.
    first = rows[0]["id"]
    db.update_article(first, last_checked_at="2001-01-01T00:00:00+00:00")
    assert db.expired_media_articles(ch["id"], 1)[0]["id"] != first
    assert 4 not in [a["id"] for a in db.expired_media_articles(ch["id"], 10, include_upgrades=False)]


def test_old_failed_article_is_recovered_in_normal_pipeline(settings, db):
    ch = db.create_channel("t", fetch_mode="http", collect_media=0, recheck_days=0)
    settings.crawl.max_articles_per_run = 5
    settings.crawl.max_rechecks_per_run = 0
    db.upsert_discovered(ch["id"], _rows(*range(1, 21)), None)
    db.mark_article_failure(1, "failed", "SERVER_ERROR", "504", PAST, attempts=1)
    pages = {"https://arca.live/b/t?p=1": (200, list_html("t", [20]))}
    pages.update({f"https://arca.live/b/t/{aid}": (200, article_html("t", aid, images=0))
                  for aid in [1, 20, 19, 18, 17]})
    fetcher = FakeFetcher("http", pages)
    run = run_channel(settings, db, ch["id"], fetcher_factory=make_factory(fetcher, None))
    assert run["status"] == "success"
    assert run["stats"]["collected"] == 5
    assert db.get_article(1)["state"] == "collected"
    assert db.get_article(1)["next_retry_at"] is None
    assert db.get_article(16)["state"] == "discovered"


def test_refreshed_expired_file_precedes_other_pending_files(db):
    ch = db.create_channel("t")
    db.upsert_discovered(ch["id"], _rows(1), None)
    items = [{"seq": i, "kind": "image", "source_key": f"media/{i}"} for i in [1, 99]]
    media = db.upsert_media(1, items)
    db.update_media(media[1]["id"], state="expired", state_code="URL_EXPIRED")
    db.upsert_media(1, items)
    assert db.pending_media_for_article(1)[0]["id"] == media[1]["id"]


def test_expired_media_is_refreshed_and_downloaded_before_new_backlog(settings, db, monkeypatch):
    from arca_archive.pipeline.runner import CrawlContext
    from arca_archive.pipeline.recheck import recheck
    from pathlib import Path

    ch = db.create_channel("t", fetch_mode="http", recheck_days=0)
    settings.media.request_original = False
    db.upsert_discovered(ch["id"], _rows(1, 2), None)
    for aid in [1, 2]:
        db.update_article(aid, state="collected", last_checked_at=PAST)
        db.upsert_media(aid, [{"seq": 1, "kind": "image", "source_key": f"ac.arca.live/2026/{aid}_0.png",
                              "served_url": f"https://ac.arca.live/2026/{aid}_0.png?expires=1"}])
    old = db.list_media(1)[0]
    db.update_media(old["id"], state="expired", state_code="URL_EXPIRED")
    pages = {"https://arca.live/b/t/1": (200, article_html("t", 1))}
    fetcher = FakeFetcher("http", pages, {"https://ac.arca.live/2026/1_0.png": (200, PNG, "image/png")})
    run = db.create_run(ch, "manual")
    ctx = CrawlContext(settings, db, run, ch, fetcher_factory=make_factory(fetcher, None))
    ctx.set_stage("recheck")
    # Only enough time for one article: older expired media must get that slot.
    monkeypatch.setattr(ctx, "media_budget_exhausted", lambda: bool(ctx.stats.media_downloaded))
    try:
        result = recheck(ctx)
    finally:
        ctx.close_fetcher()
    assert result["handled"] == 1
    assert fetcher.requests == ["https://arca.live/b/t/1"]
    restored = db.list_media(1)
    assert len(restored) == 1
    assert restored[0]["state"] == "downloaded"
    assert Path(restored[0]["file_path"]).read_bytes() == PNG
    assert db.list_media(2)[0]["state"] == "pending"
    assert db.get_run(run["id"])["stats"]["media_downloaded"] == 1


def test_stale_original_signature_does_not_block_fresh_served_url(settings, db):
    from arca_archive.pipeline.media import _is_expired, original_candidates, converted_candidates

    ch = db.create_channel("t", fetch_mode="http", recheck_days=0)
    # The live pages retained an expired data-originalurl but refreshed img/video src.
    body = article_html("t", 1).replace(
        "https://ac-o.arca.live/2026/1_0.png?expires=9999999999",
        "https://ac-o.arca.live/2026/1_0.png?expires=1")
    pages = {"https://arca.live/b/t?p=1": (200, list_html("t", [1])),
             "https://arca.live/b/t/1": (200, body)}
    fetcher = FakeFetcher("http", pages, {
        "https://ac-o.arca.live/2026/1_0.png": (403, b"", "text/xml"),
        "https://ac.arca.live/2026/1_0.png": (200, PNG, "image/png"),
    })
    run = run_channel(settings, db, ch["id"], fetcher_factory=make_factory(fetcher, None))
    media = db.list_media(1)[0]
    assert run["stats"]["media_downloaded"] == 1
    assert media["state"] == "downloaded" and media["is_original"] == 0
    assert not _is_expired(media)
    assert all("expires=1&" not in u for u in fetcher.download_requests)
    # The inverse case also works, while genuinely expired URLs remain blocked.
    swapped = {"served_url": media["original_url"], "original_url": media["served_url"]}
    assert not _is_expired(swapped)
    assert converted_candidates(swapped) == []
    assert len(original_candidates(swapped)) == 1
    both_stale = {"served_url": media["original_url"], "original_url": media["original_url"]}
    assert _is_expired(both_stale)
    assert original_candidates(both_stale) == []
    assert converted_candidates(both_stale) == []
