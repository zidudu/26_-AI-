import json
import pytest
from arca_archive.archive_bundle import audit_files, create_bundle, verify_bundle, restore_bundle, file_hash
from arca_archive.db import Database
from test_db import _rows

def test_backup_is_independent_and_restore_rebases_paths(settings, db, tmp_path):
    ch = db.create_channel('t')
    db.upsert_discovered(ch['id'], _rows(1), None)
    m = db.upsert_media(1, [{'seq': 1, 'kind': 'image', 'source_key': 'a'}])[0]
    path = settings.media_path/'a.png'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b'archive-test')
    db.update_media(m['id'], state='downloaded', file_path=str(path), file_size=path.stat().st_size, sha256=file_hash(path))
    assert audit_files(db)['ok']
    db.set_bookmark('article', 1, True)
    db.set_bookmark('media', m['id'], True)
    bundle = tmp_path/'bundle'
    create_bundle(settings, db, bundle)
    path.write_bytes(b'corrupt-live-source')
    assert not audit_files(db)['ok']
    assert verify_bundle(bundle)['ok']
    restored = tmp_path/'restore'
    assert restore_bundle(bundle, restored)['ok']
    restored_db = Database(restored/'data'/'arca.sqlite3')
    try:
        assert audit_files(restored_db)['ok']
        assert restored_db.bookmarked_ids('article', [1]) == {1}
        assert restored_db.bookmarked_ids('media', [m['id']]) == {m['id']}
        assert restored_db.get_media(m['id'])['file_path'].startswith(str(restored))
        assert not json.loads((restored/'config'/'settings.json').read_text())['scheduler_enabled']
    finally:
        restored_db.close()

def test_manifest_cannot_escape_destination(tmp_path):
    bundle = tmp_path/'bad'
    bundle.mkdir()
    (bundle/'manifest.json').write_text(json.dumps({'scope':'full','files':[{'path':'../secret','bytes':1,'sha256':'x'}]}))
    with pytest.raises(ValueError, match='escapes'):
        verify_bundle(bundle)
