from __future__ import annotations

from fastapi.testclient import TestClient

from arca_archive.db import Database
from arca_archive.web.app import create_app


class DummyService:
    def __init__(self):
        self.requests = []
        self.scheduler_enabled = True

    def start(self):
        pass

    def shutdown(self):
        pass

    def status(self):
        return {"running": False, "current": None, "run": None, "queue": [], "scheduler_enabled": True,
                "login_window_open": False, "session": {"logged_in": None}, "last_error": None, "time": ""}

    def request_run(self, channel_id, trigger="manual"):
        self.requests.append(channel_id)
        return {"ok": True}

    def stop_current(self):
        return {"ok": True, "message": "stopped"}

    def open_login_window(self, url):
        return {"ok": True, "message": "opened"}

    def check_session(self):
        return {"ok": True, "logged_in": True}


def test_pages_and_api(settings, db: Database):
    service = DummyService()
    app = create_app(settings, db, service)
    with TestClient(app) as client:
        assert client.get("/").status_code == 200
        r = client.post("/channels", data={"slug": "https://arca.live/b/ailove", "fetch_mode": "auto", "interval_minutes": 30},
                        follow_redirects=False)
        assert r.status_code == 303
        ch = db.get_channel_by_slug("ailove")
        assert ch and ch["interval_minutes"] == 30
        r = client.post(f"/channels/{ch['id']}", data={"name": "AI", "fetch_mode": "browser", "interval_minutes": "15",
                                                          "initial_pages": "3", "max_pages_per_run": "10", "recheck_days": "2",
                                                          "enabled": "on", "collect_media": "on"}, follow_redirects=False)
        assert r.status_code == 303
        ch = db.get_channel(ch["id"])
        assert ch["fetch_mode"] == "browser" and ch["interval_minutes"] == 15 and ch["collect_comments"] == 0
        assert client.post(f"/api/run/{ch['id']}").json()["ok"] is True
        assert service.requests == [ch["id"]]
        for path in ("/channels", f"/channels/{ch['id']}", "/runs", "/articles", "/media", "/errors", "/settings", "/session",
                     "/api/status", "/api/docs"):
            assert client.get(path).status_code == 200, path
        db.upsert_discovered(ch["id"], [{"id": 1, "url": "https://arca.live/b/ailove/1", "title": "t"}], None)
        db.save_collected(1, {"title": "t", "body_text": "b", "body_hash": "h"}, None, None)
        assert client.get("/articles/1").status_code == 200
        assert client.get("/articles/999").status_code == 404
        r = client.post("/settings", data={"settings_json": "{bad json"}, follow_redirects=False)
        from urllib.parse import unquote
        assert r.status_code == 303 and "실패" in unquote(r.headers["location"])
        good = client.get("/settings").text
        assert "settings_json" in good
        assert client.post("/api/stop").json()["ok"] is True


def test_channel_toggle_pauses_and_resumes_schedule(settings, db: Database):
    service = DummyService()
    service.dropped = []
    service.drop_scheduled = lambda cid: service.dropped.append(cid)
    app = create_app(settings, db, service)
    with TestClient(app) as client:
        ch = db.create_channel("p")
        db.update_channel(ch["id"], next_run_at="2026-01-01T00:00:00+00:00")
        r = client.post(f"/channels/{ch['id']}/toggle", headers={"referer": "http://127.0.0.1:8765/"}, follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"].startswith("/?m=")
        assert db.get_channel(ch["id"])["enabled"] == 0 and service.dropped == [ch["id"]]
        page = client.get("/").text
        assert "재개" in page and "일시중지" in page
        r = client.post(f"/channels/{ch['id']}/toggle", follow_redirects=False)
        assert db.get_channel(ch["id"])["enabled"] == 1
        assert client.get("/channels").status_code == 200


def test_list_pages_accept_empty_filters_and_paginate(settings, db: Database):
    app = create_app(settings, db, DummyService())
    with TestClient(app) as client:
        ch = db.create_channel("pg")
        rows = [{"id": i, "url": f"https://arca.live/b/pg/{i}", "title": f"t{i}"} for i in range(1, 131)]
        db.upsert_discovered(ch["id"], rows, None)
        for i in range(1, 131):
            db.upsert_media(i, [{"seq": 1, "kind": "image", "source_key": f"ac.arca.live/{i}.png"}])
        # 빈 필터 + 페이지: 이전에는 422
        for path in ("/media?channel_id=&kind=&state=&page=2", "/articles?channel_id=&state=&q=&page=2",
                     "/runs?channel_id=", "/media?channel_id=abc", "/articles?page=abc"):
            r = client.get(path)
            assert r.status_code == 200, path
        html = client.get("/media?channel_id=&kind=&state=&page=2").text
        assert "2/3 페이지" in html and 'href="/media?page=3"' in html and 'href="/media"' in html
        # 범위 밖 페이지는 마지막 페이지로
        html = client.get("/articles?page=99").text
        assert "3/3 페이지" in html
        # 필터는 페이지 링크에 유지
        html = client.get(f"/media?channel_id={ch['id']}&kind=image&page=1").text
        assert f"/media?channel_id={ch['id']}&amp;kind=image&amp;page=2" in html


def test_channel_add_tolerates_url_forms_and_blank_interval(settings, db: Database):
    app = create_app(settings, db, DummyService())
    with TestClient(app) as client:
        r = client.post("/channels", data={"slug": "https://arca.live/b/foo/?p=2", "fetch_mode": "auto", "interval_minutes": ""},
                        follow_redirects=False)
        assert r.status_code == 303 and db.get_channel_by_slug("foo")["interval_minutes"] == settings.crawl.default_interval_minutes
        r = client.post("/channels", data={"slug": "  bar  ", "fetch_mode": "weird", "interval_minutes": "15"}, follow_redirects=False)
        assert db.get_channel_by_slug("bar")["fetch_mode"] == "auto" and db.get_channel_by_slug("bar")["interval_minutes"] == 15
        r = client.post("/channels", data={"slug": "bad slug!", "fetch_mode": "auto", "interval_minutes": "5"}, follow_redirects=False)
        assert "올바르지" in __import__("urllib.parse").parse.unquote(r.headers["location"])


def test_media_pages_use_in_page_viewer_not_new_tab(settings, db: Database):
    app = create_app(settings, db, DummyService())
    with TestClient(app) as client:
        ch = db.create_channel("v")
        db.upsert_discovered(ch["id"], [{"id": 3, "url": "https://arca.live/b/v/3", "title": "t"}], None)
        db.save_collected(3, {"title": "t", "body_text": "b", "body_hash": "h"}, None, None)
        path = settings.media_path / "v" / "3" / "01_abc.png"
        path.parent.mkdir(parents=True)
        path.write_bytes(b"\x89PNG")
        db.upsert_media(3, [{"seq": 1, "kind": "image", "source_key": "ac.arca.live/a.png"}])
        mid = db.list_media(3)[0]["id"]
        db.update_media(mid, state="downloaded", file_path=str(path), sha256="s", file_size=4)
        for url in ("/media", "/articles/3"):
            html = client.get(url).text
            assert "data-viewer" in html and 'data-kind="image"' in html, url
            thumb = html[html.index("data-viewer") - 200: html.index("data-viewer") + 50]
            assert 'target="_blank"' not in thumb  # 썸네일은 새 창이 아니라 화면 안 뷰어로
        assert "data-viewer" in client.get("/static/app.js").text
