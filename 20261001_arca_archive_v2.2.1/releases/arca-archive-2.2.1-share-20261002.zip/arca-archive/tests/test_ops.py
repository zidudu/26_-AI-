from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from arca_archive.db import Database, SCHEMA_VERSION
from arca_archive.export import export_articles_jsonl
from arca_archive.pipeline.runner import run_channel
from arca_archive.web.app import create_app
from test_pipeline import FakeFetcher, article_html, list_html, make_factory
from test_web import DummyService


def test_backfill_scans_requested_pages_ignoring_known(settings, db: Database):
    slug = "bf"
    ch = db.create_channel(slug, initial_pages=1, max_pages_per_run=5)
    pages = {f"https://arca.live/b/{slug}?p={n}": (200, list_html(slug, [100 - n * 2, 99 - n * 2], has_next=True, page=n)) for n in range(1, 6)}
    for i in range(80, 101):
        pages[f"https://arca.live/b/{slug}/{i}"] = (200, article_html(slug, i, images=0))
    run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(FakeFetcher("http", pages), None))
    assert db.count_articles_by_state(ch["id"])["collected"] == 2  # 첫 실행 1페이지
    # 평소 증분: 1페이지가 모두 아는 글 → 멈춤
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(FakeFetcher("http", pages), None))
    assert run["stats"]["discover_reason"] == "REACHED_KNOWN" and run["stats"]["pages_scanned"] == 1
    # 백필 3페이지 예약 → 아는 글이 있어도 3페이지까지 훑고 예약 해제
    db.update_channel(ch["id"], backfill_pages=3)
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(FakeFetcher("http", pages), None))
    assert run["stats"]["pages_scanned"] == 3 and run["stats"]["discover_reason"] == "BACKFILL_DONE"
    assert run["stats"]["discovered_new"] == 4 and db.get_channel(ch["id"])["backfill_pages"] == 0
    assert run["stats"]["coverage_complete"] is True


def test_backfill_button_and_schema_v3(settings, db: Database):
    service = DummyService()
    service.requests = []
    service.request_run = lambda cid, trigger="manual": service.requests.append(cid) or {"ok": True}
    app = create_app(settings, db, service)
    with TestClient(app) as client:
        ch = db.create_channel("b")
        r = client.post(f"/channels/{ch['id']}/backfill", data={"pages": "20"}, follow_redirects=False)
        assert r.status_code == 303 and db.get_channel(ch["id"])["backfill_pages"] == 20 and service.requests == [ch["id"]]
        r = client.post(f"/channels/{ch['id']}/backfill", data={"pages": "0"}, follow_redirects=False)
        assert db.get_channel(ch["id"])["backfill_pages"] == 20
        assert client.get(f"/channels/{ch['id']}").status_code == 200
    assert db.connect().execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION


def test_event_purge_backup_and_export(settings, db: Database, tmp_path):
    ch = db.create_channel("e")
    run = db.create_run(ch, "manual")
    db.add_event(run["id"], "info", "old")
    db.connect().execute("UPDATE run_events SET at='2000-01-01T00:00:00+00:00'")
    db.add_event(run["id"], "info", "new")
    assert db.purge_old_events(30) == 1 and len(db.list_events(run["id"])) == 1
    db.upsert_discovered(ch["id"], [{"id": 7, "url": "https://arca.live/b/e/7", "title": "t"}], None)
    db.save_collected(7, {"title": "t", "body_text": "b", "body_hash": "h", "badges": ["x"]}, None, None)
    db.upsert_media(7, [{"seq": 1, "kind": "image", "source_key": "ac.arca.live/a.png"}])
    db.replace_comments(7, [{"id": 1, "author": "a", "body_text": "c", "body_html": ""}])
    backup = db.backup_to(tmp_path / "b" / "x.sqlite3")
    other = sqlite3.connect(backup)
    assert other.execute("SELECT COUNT(*) FROM articles").fetchone()[0] == 1
    other.close()
    out = tmp_path / "out.jsonl"
    assert export_articles_jsonl(db, out, ch["id"]) == 1
    record = json.loads(out.read_text(encoding="utf-8").splitlines()[0])
    assert record["id"] == 7 and record["badges"] == ["x"] and record["media"][0]["kind"] == "image" and record["comments"][0]["body_text"] == "c"
    app = create_app(settings, db, DummyService())
    with TestClient(app) as client:
        r = client.get("/api/export/articles.jsonl?channel_id=")
        assert r.status_code == 200 and r.text.count("\n") == 1
        r = client.post("/backup", headers={"referer": "http://127.0.0.1:8765/settings"}, follow_redirects=False)
        assert r.status_code == 303 and "백업" in __import__("urllib.parse").parse.unquote(r.headers["location"])
        assert any(p.suffix == ".sqlite3" for p in (settings.data_path / "backups").iterdir())
        assert "미디어 용량" in client.get("/").text
