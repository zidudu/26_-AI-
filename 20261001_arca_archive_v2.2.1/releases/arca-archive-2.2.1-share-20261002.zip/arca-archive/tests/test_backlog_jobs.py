import threading
import hashlib
from pathlib import Path
import httpx
import pytest
from fastapi.testclient import TestClient

from arca_archive.backlog import inspect_backlog
from arca_archive.common import AppError
from arca_archive.fetch.download import stream_download
from arca_archive.pipeline.runner import CrawlContext, run_channel
from arca_archive.service import CrawlerService
from arca_archive.web.app import create_app
from test_db import _rows
from test_pipeline import FakeFetcher, PNG, article_html, make_factory

PAST = '2000-01-01T00:00:00+00:00'
FUTURE = '2999-01-01T00:00:00+00:00'

def test_backlog_ignores_new_posts_and_preserves_discovery_schedule(settings, db):
    ch = db.create_channel('t', fetch_mode='http', recheck_days=0)
    db.update_channel(ch['id'], next_run_at=FUTURE, next_media_at=PAST)
    settings.media.request_original = False
    settings.media.backlog_files_per_article = 1
    db.upsert_discovered(ch['id'], _rows(1, 2), None)
    db.update_article(1, state='collected')
    db.upsert_media(1, [{'seq': 1, 'kind': 'image', 'source_key': 'ac.arca.live/2026/1_0.png'}])
    service = CrawlerService(settings, db)
    assert service._next_due() == (ch['id'], 'backlog')
    assert service.status()['next_due']['trigger'] == 'backlog'
    fake = FakeFetcher('http', {'https://arca.live/b/t/1': (200, article_html('t', 1, images=2))},
                       {'https://ac.arca.live/2026/1_0.png': (200, PNG, 'image/png')})
    result = run_channel(settings, db, ch['id'], 'backlog_manual', fetcher_factory=make_factory(fake, None))
    assert result['stats']['media_existing_downloaded'] == 1
    assert result['stats']['media_new_downloaded'] == 0
    assert result['stats']['media_created'] == 1
    assert db.get_article(2)['state'] == 'discovered'
    assert fake.requests == ['https://arca.live/b/t/1']
    assert db.get_channel(ch['id'])['next_run_at'] == FUTURE
    assert db.get_channel(ch['id'])['next_media_at'] != PAST

def test_persisted_queue_survives_new_service_and_explicit_stop_clears(settings, db):
    ch = db.create_channel('t')
    first = CrawlerService(settings, db)
    assert first.request_run(ch['id'], 'backlog_manual')['ok']
    second = CrawlerService(settings, db)
    assert second.status()['queue'][0]['trigger'] == 'backlog_manual'
    second.stop_current()
    assert not CrawlerService(settings, db).status()['queue']

def test_body_missing_reference_does_not_delete_downloaded_files(db):
    ch = db.create_channel('t')
    db.upsert_discovered(ch['id'], _rows(1), None)
    media = db.upsert_media(1, [{'seq': i, 'kind': 'image', 'source_key': str(i)} for i in [1, 2]])
    db.update_media(media[0]['id'], state='downloaded', file_path='preserved.png')
    assert db.reconcile_body_media(1, set()) == 1
    assert db.get_media(media[0]['id'])['file_path'] == 'preserved.png'
    assert db.get_media(media[1]['id'])['state_code'] == 'SOURCE_NOT_PRESENT'
    db.upsert_media(1, [{'seq': 2, 'kind': 'image', 'source_key': '2'}])
    assert db.get_media(media[1]['id'])['state'] == 'pending'

def test_backlog_reasons_partition_and_pause_delay(settings, db):
    ch = db.create_channel('t')
    db.upsert_discovered(ch['id'], _rows(1, 2), None)
    for aid in [1, 2]:
        db.upsert_media(aid, [{'seq': 1, 'kind': 'image', 'source_key': str(aid)}])
    db.update_article(1, state='collected')
    m = db.list_media(1)[0]
    db.update_media(m['id'], state_code='DOWNLOAD_PAUSED', next_retry_at=FUTURE)
    assert db.pending_media_for_article(1) == []
    report = inspect_backlog(db)
    assert report['counts'] == {'retry_scheduled': 1, 'article_pending': 1}
    db.update_channel(ch['id'], enabled=0)
    assert inspect_backlog(db)['counts'] == {'channel_paused': 2}

def test_aiart_backlog_file_limit_is_scoped_to_channel(settings, db):
    settings.media.request_original = False
    settings.media.backlog_files_per_article = 1
    settings.media.backlog_files_per_article_by_channel = {'aiart': 2}
    aiart = db.create_channel('aiart', fetch_mode='http')
    other = db.create_channel('other', fetch_mode='http')
    for channel, aid in ((aiart, 1), (other, 2)):
        db.upsert_discovered(channel['id'], _rows(aid), None)
        db.update_article(aid, state='collected', url=f'https://arca.live/b/{channel["slug"]}/{aid}')
        db.upsert_media(aid, [
            {'seq': seq + 1, 'kind': 'image', 'source_key': f'ac.arca.live/2026/{aid}_{seq}.png'}
            for seq in range(3)
        ])
        fake = FakeFetcher('http', {f'https://arca.live/b/{channel["slug"]}/{aid}':
                            (200, article_html(channel['slug'], aid, images=3))},
                           {f'https://ac.arca.live/2026/{aid}_{seq}.png': (200, PNG, 'image/png')
                            for seq in range(3)})
        result = run_channel(settings, db, channel['id'], 'backlog_manual', fetcher_factory=make_factory(fake, None))
        assert result['stats']['media_existing_downloaded'] == (2 if channel['slug'] == 'aiart' else 1)
        assert sum(m['state'] == 'pending' for m in db.list_media(aid)) == (1 if channel['slug'] == 'aiart' else 2)

def test_aiart_backlog_time_budget_is_scoped_to_channel(settings, db):
    settings.media.backlog_time_budget_minutes = 10
    settings.media.backlog_time_budget_by_channel = {'aiart': 20}
    for slug, expected_seconds in (('aiart', 1200), ('other', 600)):
        channel = db.create_channel(slug)
        run = db.create_run(channel, 'backlog_manual')
        ctx = CrawlContext(settings, db, run, channel, threading.Event())
        assert ctx.backlog_time_budget_seconds() == expected_seconds
        ctx.started_monotonic -= 15 * 60
        assert ctx.media_budget_exhausted() == (slug == 'other')

def test_recheck_451_is_recorded_without_losing_collected_article(settings, db):
    ch = db.create_channel('aiart', fetch_mode='browser')
    db.upsert_discovered(ch['id'], _rows(1), None)
    db.update_article(1, state='collected', url='https://arca.live/b/aiart/1')
    db.upsert_media(1, [{'seq': 1, 'kind': 'image', 'source_key': 'old'}])
    browser = FakeFetcher('browser', {'https://arca.live/b/aiart/1': (451, '<title>Unavailable For Legal Reasons</title>')})
    result = run_channel(settings, db, ch['id'], 'backlog_manual', fetcher_factory=make_factory(None, browser))
    assert result['status'] == 'failed' and result['code'] == 'BLOCKED_451'
    article = db.get_article(1)
    assert article['state'] == 'collected' and article['state_code'] == 'BLOCKED_451'
    assert article['next_retry_at'] and db.list_media(1)[0]['state'] == 'pending'
    assert inspect_backlog(db, ch['id'])['counts'] == {'access_blocked': 1}
    assert db.expired_media_articles(ch['id'], 10) == []
    assert ch['id'] not in db.media_work_channels()
    with TestClient(create_app(settings, db)) as client:
        page = client.get(f'/backlog?channel_id={ch["id"]}&reason=access_blocked')
        assert page.status_code == 200 and 'BLOCKED_451' in page.text
        assert '원문 HTTP 451 기록' in page.text
        assert '대기 원인 보기' in client.get(f'/media?channel_id={ch["id"]}').text
    db.update_article(1, next_retry_at=PAST)
    assert [a['id'] for a in db.expired_media_articles(ch['id'], 10)] == [1]

def test_authenticated_article_451_does_not_stop_other_backlog_articles(settings, db):
    settings.media.request_original = False
    ch = db.create_channel('aiart', fetch_mode='browser')
    db.upsert_discovered(ch['id'], _rows(1, 2), None)
    for aid, checked in ((1, PAST), (2, FUTURE)):
        db.update_article(aid, state='collected', url=f'https://arca.live/b/aiart/{aid}',
                          last_checked_at=checked)
    db.upsert_media(1, [{'seq': 1, 'kind': 'image', 'source_key': 'old'}])
    db.upsert_media(2, [{'seq': 1, 'kind': 'image', 'source_key': 'ac.arca.live/2026/2_0.png'}])
    browser = FakeFetcher('browser', {
        'https://arca.live/b/aiart/1': (451, '<title>Unavailable For Legal Reasons</title>'),
        'https://arca.live/': (200, '<a href="/u/logout">logout</a>'),
        'https://arca.live/b/aiart/2': (200, article_html('aiart', 2, images=1)),
    }, {'https://ac.arca.live/2026/2_0.png': (200, PNG, 'image/png')})
    result = run_channel(settings, db, ch['id'], 'backlog_manual', fetcher_factory=make_factory(None, browser))
    assert result['stats']['blocked'] == 1
    assert result['stats']['media_existing_downloaded'] == 1
    assert db.get_article(1)['state_code'] == 'BLOCKED_451'
    assert db.list_media(2)[0]['state'] == 'downloaded'

class Chunks(httpx.SyncByteStream):
    def __iter__(self):
        yield b'a' * 65536
        yield b'b' * 65536

def test_time_limited_download_resumes_with_validator(tmp_path):
    part = tmp_path / '1.part'
    seen = []
    def handler(request):
        seen.append(dict(request.headers))
        if 'range' in request.headers:
            assert request.headers['if-range'] == '"v1"'
            return httpx.Response(206, headers={'content-range': 'bytes 65536-131071/131072', 'content-length': '65536'}, content=b'b'*65536)
        return httpx.Response(200, headers={'content-length': '131072', 'etag': '"v1"'}, stream=Chunks())
    client = httpx.Client(transport=httpx.MockTransport(handler))
    with pytest.raises(AppError, match='DOWNLOAD_PAUSED'):
        stream_download(client, 'https://example.org/a', '', 200000, max_duration_seconds=-1, resume_path=part)
    assert part.stat().st_size == 65536
    result = stream_download(client, 'https://example.org/a', '', 200000, resume_path=part)
    assert result.data == b'a'*65536+b'b'*65536
    assert seen[1]['range'] == 'bytes=65536-'
    assert not part.exists()

@pytest.mark.parametrize('bad_range', ['bytes 0-131071/131072', 'bytes 65536-131071/200000'])
def test_invalid_range_is_not_saved_as_complete(tmp_path, bad_range):
    import json
    part = tmp_path / '1.part'
    part.write_bytes(b'a'*65536)
    part.with_suffix('.json').write_text(json.dumps({'validator': '"v1"', 'total': 131072,'partial_sha256':hashlib.sha256(part.read_bytes()).hexdigest()}))
    client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(206, headers={'content-range': bad_range}, content=b'wrong')))
    with pytest.raises(AppError, match='INVALID_RANGE'):
        stream_download(client, 'https://example.org/a', '', 200000, resume_path=part)
    assert not part.exists()

def test_changed_file_full_response_replaces_partial(tmp_path):
    import json
    part = tmp_path / '1.part'
    part.write_bytes(b'old')
    part.with_suffix('.json').write_text(json.dumps({'validator': '"old"', 'total': 10,'partial_sha256':hashlib.sha256(part.read_bytes()).hexdigest()}))
    client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, headers={'etag': '"new"'}, content=b'new-file')))
    assert stream_download(client, 'https://example.org/a', '', 200000, resume_path=part).data == b'new-file'

def test_corrupt_partial_restarts_without_range(tmp_path):
    import json
    part = tmp_path/'1.part'
    part.write_bytes(b'bad')
    part.with_suffix('.json').write_text(json.dumps({'validator':'"old"','total':10,'partial_sha256':hashlib.sha256(b'old').hexdigest()}))
    def handler(request):
        assert 'range' not in request.headers
        return httpx.Response(200,headers={'etag':'"v2"'},content=b'clean-file')
    result = stream_download(httpx.Client(transport=httpx.MockTransport(handler)), 'https://example.org/a', '', 200000, resume_path=part)
    assert result.data == b'clean-file'
