import hashlib
import json
import sqlite3
from types import SimpleNamespace

import pytest

from arca_archive.fetch.base import DownloadResult
from scripts.diagnose_backlog import Recorder, TimedFetcher, audit_sample_files, bucket, choose_sample, magic_format, paused_service


def row(mid, aid, kind="image", enabled=1, state="collected", cid=1):
    return dict(id=mid, article_id=aid, kind=kind, enabled=enabled, article_state=state,
                channel_id=cid, collect_media=1, site="arca", created_at=f"2026-09-{mid:02}T00:00:00+00:00")


def test_sampling_covers_distinct_posts_and_special_states_without_disabled_channel():
    population = [row(1, 10), row(2, 10), row(3, 30), row(4, 40), row(5, 50),
                  row(6, 60, "video"), row(7, 70, "video"), row(8, 80, enabled=0),
                  row(9, 90, state="deleted"), row(10, 100, state="discovered")]
    selected = choose_sample(list(reversed(population)))
    assert [r["id"] for r in selected] == [1, 4, 5, 6, 7, 9, 10]
    assert bucket(population[7]) == "disabled_channel"
    assert bucket(population[8]) == "parent_deleted"


def test_pause_restores_interrupted_run_and_scheduler_on_probe_failure(tmp_path):
    calls = []
    state = dict(queue=[], login_window_open=False, stopping=False, running=True,
                 scheduler_enabled=True, current={"channel_id": 3})

    def api(path, data=None):
        calls.append((path, data))
        if path == "/scheduler":
            state["scheduler_enabled"] = data["enabled"] == "on"
        elif path == "/api/stop":
            state["running"] = False
        return dict(state)

    with pytest.raises(ValueError):
        with paused_service(api, tmp_path):
            assert not state["running"] and not state["scheduler_enabled"]
            raise ValueError("probe failed")
    assert state["scheduler_enabled"]
    assert ("/api/run/3", {}) in calls
    assert (tmp_path / "runtime_restore.json").exists()


def test_timing_preserves_response_and_does_not_log_url_secrets(tmp_path):
    expected = DownloadResult("https://ac.arca.live/file?key=secret&type=orig", 200, b"image", "image/png")

    class Fetcher:
        def download(self, url, **kwargs):
            assert kwargs == {"referer": "https://arca.live/b/test/1", "max_bytes": 50}
            return expected

    recorder = Recorder(tmp_path / "requests.jsonl")
    actual = TimedFetcher(Fetcher(), recorder).download(expected.url, referer="https://arca.live/b/test/1", max_bytes=50)
    assert actual is expected
    assert recorder.rows[0]["bytes"] == 5
    assert recorder.rows[0]["original_request"] is True
    assert recorder.rows[0]["seconds"] >= 0
    assert "secret" not in recorder.path.read_text()


def test_file_format_uses_bytes_instead_of_url_or_db_original_flag():
    assert magic_format(b"GIF89a" + b"\x00" * 20) == "gif"
    assert magic_format(bytes.fromhex("000000206674797069736f6d")) == "mp4_family"
    assert magic_format(b"<Error>AccessDenied</Error>") == "unknown"


def test_audit_detects_gif_original_claim_even_with_misleading_content_type(tmp_path):
    data = bytes.fromhex("000000206674797069736f6d")
    media = tmp_path / "download.gif"
    media.write_bytes(data)
    database = tmp_path / "audit.sqlite3"
    with sqlite3.connect(database) as conn:
        conn.execute("CREATE TABLE media(id,file_path,original_url,source_key,is_original,sha256,file_size,content_type)")
        conn.execute("INSERT INTO media VALUES(?,?,?,?,?,?,?,?)", (1, str(media), "https://example.test/source.gif",
                     "example.test/source.gif", 1, hashlib.sha256(data).hexdigest(), len(data), "image/gif"))
    (tmp_path / "probe_result.json").write_text(json.dumps({"samples": [{"id": 1, "outcome": "downloaded"}]}))
    audit = audit_sample_files(SimpleNamespace(db_path=database), tmp_path)
    assert audit[0]["original_flag_contradicted"] is True
    assert audit[0]["hash_verified"] and audit[0]["size_verified"]
    with sqlite3.connect(database) as conn:
        assert conn.execute("SELECT is_original FROM media").fetchone()[0] == 1  # audit is read-only
