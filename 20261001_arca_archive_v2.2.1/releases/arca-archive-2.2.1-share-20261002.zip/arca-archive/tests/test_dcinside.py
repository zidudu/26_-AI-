import json
import pytest
from arca_archive.sites.dcinside import DCInsideSite
from arca_archive.sites.base import ArticleParseError
from arca_archive.fetch.base import FetchResult
from arca_archive.pipeline.runner import run_channel
from arca_archive.pipeline.media import original_candidates
from test_pipeline import FakeFetcher, make_factory, PNG

LIST = '''<html><title>AI 채팅 마이너 갤러리 - 디시</title><table class="gall_list"><tr class="ub-content us-post" data-no="123" data-type="icon_pic">
<td class="gall_num">123</td><td class="gall_subject">정보</td><td class="gall_tit"><a href="/mgallery/board/view/?id=aichatting&amp;no=123">샘플</a><a class="reply_numbox"><span class="reply_num">[2]</span></a></td>
<td class="gall_writer" data-nick="샘플 작성자"></td><td class="gall_date" title="2026-09-28 01:00:00"></td><td class="gall_count">10</td><td class="gall_recommend">2</td></tr></table><div class="bottom_paging_box"><a href="?id=aichatting&amp;page=2">2</a></div></html>'''
ARTICLE = '''<html><input id="no" value="123"><input id="e_s_n_o" value="public-page-token"><input id="comment_cnt" value="2">
<div class="gallview_head"><span class="title_subject">샘플</span><span class="title_headtext">[정보]</span><div class="gall_writer" data-nick="샘플 작성자"><span class="gall_date" title="2026-09-28 01:00:00"></span></div><span class="gall_count">조회 10</span></div>
<div class="write_div"><p>본문</p><img src="https://dcimg6.dcinside.co.kr/viewimage.php?id=x&amp;no=file1" data-fileno="100"><img src="https://dcimg6.dcinside.co.kr/viewimage.php?id=x&amp;no=file2" data-fileno="101"></div></html>'''
COMMENTS = {'total_cnt':2, 'comments':[{'no':'501','parent':'123','depth':0,'c_no':0,'name':'A','memo':'첫 댓글','del_yn':'N','is_delete':'0'},
                                     {'no':'502','parent':'123','depth':1,'c_no':'501','name':'B','memo':'답글','del_yn':'N','is_delete':'0'}]}

def result(body, url='https://gall.dcinside.com/mgallery/board/lists/?id=aichatting&page=1'):
    return FetchResult(url=url,status=200,html=body,final_url=url)

def channel():
    return {'id':5,'site':'dcinside','site_channel_id':'aichatting','slug':'dc-aichatting'}

def test_dc_list_identity_and_paging():
    site=DCInsideSite()
    ch=channel()
    assert site.normalize_channel_input(site.channel_url(ch))['slug']=='dc-aichatting'
    parsed=site.parse_list(result(LIST),ch)
    assert len(parsed.rows)==1 and parsed.has_next
    assert parsed.rows[0].remote_id=='123' and parsed.rows[0].comment_count==2
    assert parsed.rows[0].created_at=='2026-09-27T16:00:00+00:00'
    assert site.internal_article_id(ch,'123')==5000000000123
    assert site.internal_article_id({**ch,'id':6},'123')!=site.internal_article_id(ch,'123')
    with pytest.raises(ValueError):
        site.normalize_channel_input('https://evil.invalid/mgallery/board/lists/?id=aichatting')

def test_same_path_images_are_not_merged_or_given_invented_original_url():
    site=DCInsideSite()
    parsed=site.parse_article(result(ARTICLE),{'remote_id':'123'},channel(),site.media_hosts([]),True)
    assert len(parsed.media)==2
    assert parsed.media[0]['source_key']!=parsed.media[1]['source_key']
    assert not original_candidates(parsed.media[0])
    with pytest.raises(ArticleParseError,match='번호'):
        site.parse_article(result(ARTICLE),{'remote_id':'124'},channel(),site.media_hosts([]),True)

def test_dc_comments_parent_and_deleted_flags():
    parsed=DCInsideSite().parse_comments(result(json.dumps(COMMENTS)))
    rows,total=parsed.rows,parsed.total
    assert total==2 and rows[0]['parent_remote_id'] is None
    assert rows[1]['parent_remote_id']=='501' and not rows[1]['is_deleted']
    with pytest.raises(ArticleParseError):
        DCInsideSite().parse_comments(result(''))

def test_dc_session_does_not_claim_arca_login(settings):
    from arca_archive.fetch.browser_fetcher import check_session
    assert check_session(settings,'dcinside')['logged_in'] is None

@pytest.mark.parametrize('comment_fail', [False, True])
def test_dc_pipeline_persists_body_media_comments_and_reports_partial(settings,db,monkeypatch,comment_fail):
    from arca_archive.fetch.ratelimit import RateLimiter
    monkeypatch.setattr(RateLimiter,'wait',lambda self:None)
    ch=db.create_channel('dc-aichatting',site='dcinside',site_channel_id='aichatting',fetch_mode='http',initial_pages=1,recheck_days=0)
    settings.crawl.max_rechecks_per_run=0
    site=DCInsideSite()
    class DCMock(FakeFetcher):
        def fetch_form(self,url,data,headers):
            assert data['e_s_n_o']=='public-page-token' and 'Referer' in headers
            return result('' if comment_fail else json.dumps(COMMENTS),url)
    fake=DCMock('http',{site.list_request(ch,1).url:(200,LIST),site.article_request(ch,{'remote_id':'123'}).url:(200,ARTICLE)},
        {'https://dcimg6.dcinside.co.kr/viewimage.php':(200,PNG,'image/png')})
    run=run_channel(settings,db,ch['id'],fetcher_factory=make_factory(fake,None))
    aid=site.internal_article_id(ch,'123')
    assert db.get_article(aid)['state']=='collected'
    assert len(db.list_media(aid))==2
    assert run['stats']['media_downloaded']==2
    assert all(m['is_original'] is None for m in db.list_media(aid))
    assert len(db.list_comments(aid))==(0 if comment_fail else 2)
    assert run['status']==('partial' if comment_fail else 'success')
    assert run['stats']['comments_incomplete']==int(comment_fail)
