from __future__ import annotations

from arca_archive.parsers.article_page import extract_media, parse_article_page, source_key_of
from arca_archive.parsers.list_page import parse_list_page
from arca_archive.parsers.page_state import classify, is_logged_in
from conftest import read_fixture


def test_public_list_rows_and_pagination():
    page = parse_list_page(read_fixture("list_public_bluearchive.html"), "bluearchive")
    normal = [r for r in page.rows if not r.is_notice]
    assert len(normal) >= 40
    assert page.notice_rows >= 3
    assert page.skipped_rows >= 1          # 광고/사이트 공지 행은 제외
    assert page.has_next and 2 in page.page_numbers
    assert page.categories and all(c[1] for c in page.categories)
    assert page.channel_name == "블루 아카이브 채널"
    assert page.logged_in is False
    row = normal[0]
    assert row.url == f"https://arca.live/b/bluearchive/{row.id}"
    assert row.title and row.author
    assert row.created_at and row.created_at.endswith("+00:00")
    assert row.channel_local_no and row.view_count is not None and row.like_count is not None
    # 등록순 목록은 ID 내림차순
    ids = [r.id for r in normal]
    assert ids == sorted(ids, reverse=True)


def test_anonymous_sensitive_channel_hides_rows():
    page = parse_list_page(read_fixture("list_anonymous_hidden_ailove.html"), "ailove")
    assert page.sensitive_channel is True
    assert page.logged_in is False
    assert all(r.is_notice for r in page.rows)
    assert page.hidden_for_anonymous is True


def test_article_with_images():
    art = parse_article_page(read_fixture("article_public_images.html"))
    assert art.id == 183411585 and art.slug == "bluearchive"
    assert art.title == "7번째 50"
    assert art.author == "axscdvfb" and art.author_type == "고정닉"
    assert art.created_at == "2026-09-18T13:40:01+00:00"
    assert art.view_count == 13 and art.like_count == 0 and art.dislike_count == 0 and art.comment_count == 1
    assert len(art.media) == 2 and all(m.kind == "image" for m in art.media)
    m = art.media[0]
    assert m.served_url.startswith("https://ac.arca.live/") and "expires=" in m.served_url
    assert m.original_url.startswith("https://ac-o.arca.live/") and "type=orig" in m.original_url
    assert m.source_key.startswith("ac.arca.live/") and "?" not in m.source_key
    assert m.url_expires_at and m.url_expires_at.endswith("+00:00")
    assert m.width == 1253 and m.height == 705
    assert "페로로지라" in art.body_text
    assert len(art.body_hash) == 64


def test_article_gif_emoticon_and_hash_stability():
    html = read_fixture("article_public_image_gif_emoticon.html")
    art = parse_article_page(html)
    kinds = [m.kind for m in art.media]
    assert kinds == ["image", "emoticon"]
    assert art.media[1].served_url.endswith(".mp4") or ".mp4?" in art.media[1].served_url
    again = parse_article_page(html)
    assert again.body_hash == art.body_hash


def test_article_vote_iframe_is_not_media():
    art = parse_article_page(read_fixture("article_public_vote_iframe.html"))
    assert art.media == []
    assert "마법소녀" in art.body_text


def test_article_text_only_and_expected_id_mismatch():
    html = read_fixture("article_public_text_only.html")
    art = parse_article_page(html, expected_id=183410718)
    assert art.badges == ["소녀전선2: 망명", "🃏스포/유출잡담"]
    assert art.category == "소녀전선2: 망명"
    assert art.comments == [] and art.comment_count == 0
    import pytest

    from arca_archive.parsers.article_page import ArticleParseError

    with pytest.raises(ArticleParseError) as exc:
        parse_article_page(html, expected_id=1)
    assert exc.value.code == "ID_MISMATCH"


def test_article_comments():
    art = parse_article_page(read_fixture("article_public_comments.html"))
    assert art.comment_count >= 30
    assert len(art.comments) >= 30
    first = art.comments[0]
    assert first.id > 0 and first.author and first.created_at
    texts = [c.body_text for c in art.comments if c.body_text]
    assert any("가운데" in t for t in texts)
    ids = [c.id for c in art.comments]
    assert len(ids) == len(set(ids))


def test_source_key_normalizes_original_host():
    assert source_key_of("https://ac-o.arca.live/2026/abc.png?expires=1&key=2&type=orig") == "ac.arca.live/2026/abc.png"
    assert source_key_of("//ac.arca.live/2026/abc.png?expires=1") == "ac.arca.live/2026/abc.png"


def test_extract_media_external_and_dedupe():
    from lxml import html as lxml_html

    node = lxml_html.fromstring(
        '<div class="article-content">'
        '<img src="//ac.arca.live/a/x.png?expires=1&key=k" data-originalurl="https://ac-o.arca.live/a/x.png?expires=1&key=k&type=orig">'
        '<img src="//ac.arca.live/a/x.png?expires=1&key=k">'
        '<video src="//ac.arca.live/a/v.mp4?expires=1&key=k" data-orig="gif"></video>'
        '<video controls><source src="//ac.arca.live/a/real.mp4?expires=1&key=k"></video>'
        '<iframe src="https://www.youtube.com/embed/abc"></iframe>'
        '<iframe class="arca-vote" src="/api/vote_detail/1"></iframe>'
        '<img class="twemoji" src="/node_modules/twemoji/x.svg" alt="😀">'
        '</div>'
    )
    refs = extract_media(node, ["ac.arca.live"])
    assert [r.kind for r in refs] == ["image", "gif", "video", "external"]
    assert refs[0].original_url.endswith("type=orig")
    assert refs[3].source_key == "www.youtube.com/embed/abc"


def test_page_state_classification():
    st = classify(451, "https://arca.live/b/ailove/1", read_fixture("article_451.html"), {})
    assert st.kind == "legal_block" and st.stop
    st = classify(403, "https://arca.live/b/x/1", "<html><title>Just a moment...</title></html>", {"cf-mitigated": "challenge"})
    assert st.kind == "challenge" and st.stop
    st = classify(200, "https://arca.live/u/login?goto=%2Fb%2Fx", "<html></html>", {})
    assert st.kind == "login_required" and st.stop
    st = classify(404, "https://arca.live/b/x/1", "<html>삭제된 게시물입니다</html>", {})
    assert st.kind == "deleted" and not st.stop and not st.retryable
    st = classify(503, "https://arca.live/b/x/1", "", {})
    assert st.kind == "server_error" and st.retryable and not st.stop
    st = classify(429, "https://arca.live/b/x/1", "", {})
    assert st.kind == "rate_limited" and st.stop
    assert classify(200, "https://arca.live/b/x/1", read_fixture("article_public_images.html"), {}).kind == "ok"
    assert is_logged_in(read_fixture("list_public_bluearchive.html")) is False


def test_comment_text_excludes_more_button():
    art = parse_article_page(read_fixture("article_public_comments.html"))
    texts = [c.body_text for c in art.comments]
    assert texts and not any("펼쳐보기" in t for t in texts)
    assert not any("btn-more" in c.body_html for c in art.comments)
    assert any("가운데" in t for t in texts)
