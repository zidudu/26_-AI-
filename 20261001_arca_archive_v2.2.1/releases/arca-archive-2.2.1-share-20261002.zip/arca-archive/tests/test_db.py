from __future__ import annotations

from arca_archive.db import Database


def _rows(*ids: int) -> list[dict]:
    return [{"id": i, "url": f"https://arca.live/b/t/{i}", "title": f"t{i}", "category": None, "badges": [],
             "author": "a", "is_notice": False, "created_at": "2026-09-18T00:00:00+00:00", "view_count": 1,
             "like_count": 0, "comment_count": 0, "channel_local_no": i} for i in ids]


def test_channel_and_discovery(db: Database):
    ch = db.create_channel("t", interval_minutes=30)
    assert ch["slug"] == "t" and ch["interval_minutes"] == 30
    new = db.upsert_discovered(ch["id"], _rows(3, 2, 1), run_id=None)
    assert new == [3, 2, 1]
    assert db.known_article_ids(ch["id"], [1, 2, 9]) == {1, 2}
    new = db.upsert_discovered(ch["id"], _rows(4, 3), run_id=None)
    assert new == [4]
    pending = db.pending_articles(ch["id"], 10)
    assert [p["id"] for p in pending] == [4, 3, 2, 1]
    assert db.count_articles_by_state(ch["id"]) == {"discovered": 4}


def test_collect_save_revision_and_media(db: Database):
    ch = db.create_channel("t")
    db.upsert_discovered(ch["id"], _rows(1), None)
    data = {"title": "hello", "body_text": "body", "body_html": "<p>body</p>", "body_hash": "h1", "author": "a",
            "created_at": "2026-09-18T00:00:00+00:00", "view_count": 5, "like_count": 1, "dislike_count": 0, "comment_count": 2}
    first = db.save_collected(1, data, run_id=None, raw_html_path=None)
    assert first == {"changed": False, "first": True}
    art = db.get_article(1)
    assert art["state"] == "collected" and art["collected_at"] and art["body_hash"] == "h1"
    again = db.save_collected(1, data, None, None)
    assert again == {"changed": False, "first": False}
    changed = db.save_collected(1, {**data, "body_text": "body2", "body_hash": "h2"}, None, None)
    assert changed == {"changed": True, "first": False}
    revs = db.list_revisions(1)
    assert len(revs) == 1 and revs[0]["body_hash"] == "h1"
    assert db.get_article(1)["revision_count"] == 1

    media = db.upsert_media(1, [
        {"seq": 1, "kind": "image", "source_key": "ac.arca.live/a.png", "served_url": "https://ac.arca.live/a.png?expires=1"},
        {"seq": 2, "kind": "external", "source_key": "youtube.com/x", "state": "skipped"},
    ])
    assert len(media) == 2
    pending = db.pending_media_for_article(1)
    assert [m["source_key"] for m in pending] == ["ac.arca.live/a.png"]
    db.update_media(pending[0]["id"], state="downloaded", file_path="x", sha256="s")
    art = db.get_article(1)
    assert art["media_total"] == 1 and art["media_done"] == 1
    # 재수집 시 URL 갱신, 상태는 유지
    db.upsert_media(1, [{"seq": 1, "kind": "image", "source_key": "ac.arca.live/a.png", "served_url": "https://ac.arca.live/a.png?expires=2"}])
    assert db.list_media(1)[0]["state"] == "downloaded"
    assert db.find_media_by_sha("s")["file_path"] == "x"


def test_failure_retry_and_requeue(db: Database):
    ch = db.create_channel("t")
    db.upsert_discovered(ch["id"], _rows(1, 2), None)
    db.mark_article_failure(1, "failed", "NETWORK_ERROR", "x", "2999-01-01T00:00:00+00:00", attempts=1)
    db.mark_article_failure(2, "error", "PARSE", "y", None, attempts=4)
    assert [p["id"] for p in db.pending_articles(ch["id"], 10)] == []
    db.mark_article_failure(1, "failed", "NETWORK_ERROR", "x", "2000-01-01T00:00:00+00:00", attempts=1)
    assert [p["id"] for p in db.pending_articles(ch["id"], 10)] == [1]
    failed = db.failed_items()
    assert {a["id"] for a in failed["articles"]} == {1, 2}
    assert db.requeue_articles(ch["id"]) == 2
    assert db.count_articles_by_state(ch["id"]) == {"failed": 2}
    assert all(a["state_code"] == "RETRY_REQUESTED" and a["attempts"] == 0
               for a in db.pending_articles(ch["id"], 10))


def test_runs_events_settings(db: Database):
    ch = db.create_channel("t")
    run = db.create_run(ch, "manual")
    assert run["status"] == "running"
    db.add_event(run["id"], "info", "list_page", page=1, rows=3)
    db.add_event(run["id"], "error", "article_error", article_id=5, code="X")
    events = db.list_events(run["id"])
    assert len(events) == 2 and events[0]["data"]["rows"] == 3
    assert db.list_events(run["id"], level="error")[0]["article_id"] == 5
    db.finish_run(run["id"], "partial", "PARTIAL", "m", {"collected": 1})
    got = db.get_run(run["id"])
    assert got["status"] == "partial" and got["stats"]["collected"] == 1 and got["finished_at"]
    assert db.recent_error_events()[0]["event"] == "article_error"
    db.set_setting("k", "v")
    db.set_setting("k", "v2")
    assert db.get_setting("k") == "v2"
    run2 = db.create_run(ch, "schedule")
    assert db.abort_stale_runs("restart") == 1
    assert db.get_run(run2["id"])["code"] == "INTERRUPTED"
