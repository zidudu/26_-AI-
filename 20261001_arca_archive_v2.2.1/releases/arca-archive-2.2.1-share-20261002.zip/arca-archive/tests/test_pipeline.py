"""가짜 fetcher로 discover → collect → media → recheck 흐름과 실패/전환 처리를 검증합니다."""
from __future__ import annotations

import threading
from pathlib import Path

from arca_archive.common import AppError
from arca_archive.db import Database, SCHEMA_VERSION
from arca_archive.fetch.base import DownloadResult, FetchResult
from arca_archive.pipeline.runner import run_channel
from conftest import read_fixture

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
JPG = b"\xff\xd8\xff\xe0" + b"\x00" * 64


def list_html(slug: str, ids: list[int], has_next: bool = False, page: int = 1) -> str:
    rows = "".join(
        f'<a class="vrow column" href="/b/{slug}/{i}?p={page}"><div class="vrow-inner"><div class="vrow-top">'
        f'<span class="vcol col-id"><span>{i}</span></span><span class="vcol col-title"><span class="badges"></span>'
        f'<span class="title">글 {i}</span><span class="info"><span class="comment-count">[1]</span></span></span></div>'
        f'<div class="vrow-bottom"><span class="vcol col-author"><span class="user-info"><span data-filter="작성자">작성자</span></span></span>'
        f'<span class="vcol col-time"><time datetime="2026-09-18T10:00:00.000Z">2026.09.18</time></span>'
        f'<span class="vcol col-view">3</span><span class="vcol col-rate">0</span></div></div></a>'
        for i in ids
    )
    nav = f'<nav class="pagination-wrapper"><ul class="pagination"><li class="page-item active"><a class="page-link" href="/b/{slug}?p={page}">{page}</a></li>'
    if has_next:
        nav += f'<li class="page-item"><a class="page-link" href="/b/{slug}?p={page + 1}">{page + 1}</a></li>'
    nav += "</ul></nav>"
    return f'<html><head><meta name="title" content="테스트 채널"><a href="/u/logout">x</a></head><body><div class="list-table">{rows}</div>{nav}</body></html>'


def article_html(slug: str, aid: int, body: str = "본문", images: int = 1, comments: int = 1) -> str:
    imgs = "".join(
        f'<p><img src="//ac.arca.live/2026/{aid}_{n}.png?expires=9999999999&key=k" width="10" height="10" '
        f'data-originalurl="https://ac-o.arca.live/2026/{aid}_{n}.png?expires=9999999999&key=k&type=orig"></p>'
        for n in range(images)
    )
    cmts = "".join(
        f'<div class="comment-wrapper"><div class="comment-item" id="c_{aid}0{n}"><div class="content">'
        f'<div class="info-row clearfix"><span class="user-info"><a data-filter="댓글러{n}">댓글러{n}</a></span>'
        f'<div class="right"><time datetime="2026-09-18T11:00:0{n}.000Z">t</time></div></div>'
        f'<div class="message"><div class="text"><pre>댓글 {n}</pre></div></div></div></div></div>'
        for n in range(comments)
    )
    return f"""<html><head><title>글 {aid}</title></head><body>
    <div class="article-wrapper"><div class="article-head"><div class="title-row"><div class="title">
    <span class="badge category-badge">자유</span> 글 {aid}</div></div>
    <div class="info-row"><div class="member-info"><span class="user-info"><a data-filter="작성자">작성자</a>
    <span class="user-icon" title="고정닉"></span></span></div>
    <div class="article-info"><span class="head">추천</span><span class="body">2</span><span class="head">비추천</span><span class="body">0</span>
    <span class="head">댓글</span><span class="body comment-count">{comments}</span><span class="head">조회수</span><span class="body">7</span>
    <span class="date"><span class="head">작성일</span><span class="body"><time datetime="2026-09-18T10:00:00.000Z">x</time></span></span></div></div></div>
    <div class="article-link"><a href="https://arca.live/b/{slug}/{aid}">u</a></div>
    <div class="article-body"><div class="fr-view article-content"><p>{body}</p>{imgs}</div></div>
    <div class="article-comment" id="comment"><div class="title"><span class="title-comment-count">[{comments}]</span></div>
    <div class="list-area">{cmts}</div></div></div></body></html>"""


class FakeFetcher:
    """URL → (status, html) 매핑. 요청 기록을 남기고 다운로드는 바이트를 돌려줍니다."""

    def __init__(self, name: str, pages: dict[str, tuple[int, str]], downloads: dict[str, tuple[int, bytes, str]] | None = None):
        self.name = name
        self.pages = pages
        self.downloads = downloads or {}
        self.requests: list[str] = []
        self.download_requests: list[str] = []
        self.closed = False
        self.session_flag = "1"   # fetch_page_capture 가 보고하는 세션 쿠키 존재 여부
        self.in_page_downloads = False
        self.block_resources = True

    def fetch_page(self, url: str) -> FetchResult:
        self.requests.append(url)
        if url not in self.pages:
            return FetchResult(url=url, status=404, html="<html>없는 페이지</html>", final_url=url, headers={}, fetcher=self.name)
        status, html = self.pages[url]
        final = url
        if status == "login":
            status, final = 200, "https://arca.live/u/login?goto=x"
        headers = {"cf-mitigated": "challenge"} if status == 403 and "Just a moment" in html else {}
        return FetchResult(url=url, status=status, html=html, final_url=final, headers=headers, fetcher=self.name)

    def fetch_api(self, url: str, headers=None, origin=None) -> FetchResult:
        r = self.fetch_page(url)
        return FetchResult(url=url, status=r.status, html=r.html, final_url=url, headers={"x-fetch-mode": "inpage"}, fetcher=self.name)

    def fetch_page_capture(self, url: str, pattern: str, session_cookies=(), timeout_seconds=None) -> FetchResult:
        """pages 표에서 pattern(정규식)에 맞는 API 항목을 '가로챈' 것으로 칩니다. 없으면 timeout 형태를 돌려줍니다."""
        import re as _re

        self.requests.append(url)
        for key, (status, html) in self.pages.items():
            if _re.search(pattern, key):
                return FetchResult(url=url, status=status, html=html, final_url=url,
                                   headers={"x-capture": "ok", "x-captured-url": key, "x-has-session": self.session_flag}, fetcher=self.name)
        page_html = self.pages.get(url, (0, ""))[1]
        return FetchResult(url=url, status=0, html=page_html, final_url=url,
                           headers={"x-capture": "timeout", "x-has-session": self.session_flag}, fetcher=self.name)

    def download(self, url: str, referer: str, max_bytes: int) -> DownloadResult:
        self.download_requests.append(url)
        key = url.split("?")[0]
        if "type=orig" in url:
            # 실제 CDN처럼 ac.arca.live + type=orig 도 원본 호스트(ac-o)와 같은 결과를 냅니다.
            key = key.replace("https://ac.arca.live/", "https://ac-o.arca.live/")
        if key in self.downloads:
            status, data, ct = self.downloads[key]
            return DownloadResult(url=url, status=status, data=data, content_type=ct, headers={})
        if "raise" in url:
            raise AppError("NETWORK_ERROR", "boom")
        return DownloadResult(url=url, status=404, data=b"", content_type=None, headers={})

    def close(self) -> None:
        self.closed = True


def make_factory(http: FakeFetcher | None, browser: FakeFetcher | None):
    created: list[str] = []

    def factory(kind: str):
        created.append(kind)
        f = http if kind == "http" else browser
        if f is None:
            raise AppError("BROWSER_START_FAILED", "no browser in test", stop=True)
        return f

    factory.created = created  # type: ignore[attr-defined]
    return factory


def test_full_run_public_channel(settings, db: Database):
    slug = "pub"
    ch = db.create_channel(slug, initial_pages=1, max_pages_per_run=5)
    pages = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [30, 20, 10], has_next=True)),
        f"https://arca.live/b/{slug}/30": (200, article_html(slug, 30, images=2, comments=2)),
        f"https://arca.live/b/{slug}/20": (200, article_html(slug, 20, images=0)),
        f"https://arca.live/b/{slug}/10": (404, "<html>삭제된 게시물입니다</html>"),
    }
    downloads = {
        f"https://ac-o.arca.live/2026/30_0.png": (200, PNG, "image/png"),
        f"https://ac-o.arca.live/2026/30_1.png": (403, b"", "text/plain"),      # 원본 거부 → 변환본으로
        f"https://ac.arca.live/2026/30_1.png": (200, JPG, "image/jpeg"),
    }
    http = FakeFetcher("http", pages, downloads)
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    assert run["status"] == "success", run
    st = run["stats"]
    assert st["pages_scanned"] == 1 and st["discovered_new"] == 3 and st["discover_reason"] == "PAGE_LIMIT"
    assert st["collected"] == 2 and st["deleted"] == 1 and st["failed"] == 0
    assert st["media_targets"] == 2 and st["media_downloaded"] == 2
    assert st["comments_saved"] == 3  # 글 30: 2개, 글 20: 1개
    a30 = db.get_article(30)
    assert a30["state"] == "collected" and a30["media_total"] == 2 and a30["media_done"] == 2
    assert a30["raw_html_path"] and Path(a30["raw_html_path"]).exists()
    media = db.list_media(30)
    assert media[0]["state"] == "downloaded" and media[0]["file_path"].endswith(".png")
    assert media[1]["file_path"].endswith(".jpg") and Path(media[1]["file_path"]).read_bytes() == JPG
    assert db.get_article(10)["state"] == "deleted"
    assert db.list_comments(30)[0]["author"] == "댓글러0"
    channel = db.get_channel(ch["id"])
    assert channel["last_max_article_id"] == 30 and channel["next_run_at"] and channel["name"] == "테스트 채널"
    assert http.closed
    # 초기 실행 이후 목록은 1페이지만 읽었으므로 첫 실행은 initial_pages 예산을 따른다.
    assert http.requests[0].endswith("?p=1")


def test_incremental_stops_at_known_and_rechecks(settings, db: Database, monkeypatch):
    from datetime import datetime, timezone
    from arca_archive.pipeline import recheck

    # Fixture posts are dated September 18; the three-day window must not depend
    # on the real calendar date of the machine running this regression test.
    monkeypatch.setattr(recheck, "utcnow", lambda: datetime(2026, 9, 19, tzinfo=timezone.utc))
    slug = "inc"
    ch = db.create_channel(slug, initial_pages=1, max_pages_per_run=5)
    pages = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [2, 1], has_next=True)),
        f"https://arca.live/b/{slug}/2": (200, article_html(slug, 2, images=0)),
        f"https://arca.live/b/{slug}/1": (200, article_html(slug, 1, images=0)),
    }
    http = FakeFetcher("http", pages)
    run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    # 두 번째 실행: 새 글 3 등록, 글 2 본문 수정. 1페이지에 아는 글이 있어도 새 글이 섞이면 다음 페이지로 감.
    pages2 = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [3, 2], has_next=True)),
        f"https://arca.live/b/{slug}?p=2": (200, list_html(slug, [1], has_next=False, page=2)),
        f"https://arca.live/b/{slug}/3": (200, article_html(slug, 3, images=0)),
        f"https://arca.live/b/{slug}/2": (200, article_html(slug, 2, body="수정된 본문", images=0)),
        f"https://arca.live/b/{slug}/1": (200, article_html(slug, 1, images=0)),
    }
    # 재확인 대상이 되도록 마지막 확인 시각을 과거로 돌립니다.
    db.update_article(2, last_checked_at="2020-01-01T00:00:00+00:00")
    db.update_article(1, last_checked_at="2020-01-01T00:00:00+00:00")
    http2 = FakeFetcher("http", pages2)
    run = run_channel(settings, db, ch["id"], "schedule", fetcher_factory=make_factory(http2, None))
    st = run["stats"]
    assert st["discover_reason"] == "REACHED_KNOWN" and st["pages_scanned"] == 2
    assert st["discovered_new"] == 1 and st["collected"] == 1
    assert st["rechecked"] == 2 and st["updated"] == 1 and st["unchanged"] == 1
    a2 = db.get_article(2)
    assert a2["revision_count"] == 1 and "수정된 본문" in a2["body_text"]
    assert db.list_revisions(2)[0]["body_text"] == "본문"
    assert run["status"] == "success"


def test_item_failures_do_not_abort_and_retry_schedule(settings, db: Database):
    slug = "fail"
    ch = db.create_channel(slug, initial_pages=1)
    pages = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [5, 4, 3])),
        f"https://arca.live/b/{slug}/5": (500, "<html>server error</html>"),
        f"https://arca.live/b/{slug}/4": (200, "<html><body>no article here</body></html>"),
        f"https://arca.live/b/{slug}/3": (200, article_html(slug, 3, images=1)),
    }
    http = FakeFetcher("http", pages, downloads={})  # 다운로드는 404
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    assert run["status"] == "partial" and run["code"] == "PARTIAL"
    st = run["stats"]
    assert st["failed"] == 2 and st["collected"] == 1 and st["media_failed"] == 1
    a5 = db.get_article(5)
    assert a5["state"] == "failed" and a5["state_code"] == "SERVER_ERROR" and a5["attempts"] == 1 and a5["next_retry_at"]
    a4 = db.get_article(4)
    assert a4["state"] == "failed" and a4["state_code"] == "PARSE_NO_ARTICLE"
    m = db.list_media(3)[0]
    assert m["state"] == "error" or m["state"] == "failed"
    assert m["state_code"] == "MEDIA_NOT_FOUND"
    errors = db.failed_items()
    assert {a["id"] for a in errors["articles"]} == {4, 5}


def test_http_escalates_to_browser_on_451(settings, db: Database):
    slug = "adult"
    ch = db.create_channel(slug, initial_pages=1, fetch_mode="auto")
    list_ok = list_html(slug, [7])
    hidden = list_ok.replace('<a href="/u/logout">x</a>', '<a href="/u/login">login</a>').replace(
        '<div class="list-table">', '<meta name="has_sensitive_media" content="1"><div class="list-table">')
    # http 로는 목록이 정상처럼 보이지만 글은 451, 브라우저로는 모두 정상
    http = FakeFetcher("http", {
        f"https://arca.live/b/{slug}?p=1": (200, list_ok),
        f"https://arca.live/b/{slug}/7": (451, read_fixture("article_451.html")),
    })
    browser = FakeFetcher("browser", {
        f"https://arca.live/b/{slug}?p=1": (200, list_ok),
        f"https://arca.live/b/{slug}/7": (200, article_html(slug, 7, images=0)),
    })
    factory = make_factory(http, browser)
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=factory)
    assert run["status"] == "success", run
    assert factory.created == ["http", "browser"]
    assert run["stats"]["fetcher_switches"] == 1 and run["stats"]["collected"] == 1
    assert db.get_channel(ch["id"])["requires_browser"] == 1
    assert http.closed and browser.closed
    # 다음 실행은 처음부터 브라우저로 시작
    browser2 = FakeFetcher("browser", {f"https://arca.live/b/{slug}?p=1": (200, list_ok)})
    factory2 = make_factory(None, browser2)
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=factory2)
    assert factory2.created == ["browser"] and run2["status"] == "success"
    assert run2["stats"]["discover_reason"] == "REACHED_KNOWN"


def test_login_required_aborts_run(settings, db: Database):
    slug = "login"
    ch = db.create_channel(slug, initial_pages=1, fetch_mode="browser")
    browser = FakeFetcher("browser", {f"https://arca.live/b/{slug}?p=1": ("login", "<html></html>")})
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(None, browser))
    assert run["status"] == "failed" and run["code"] == "LOGIN_REQUIRED"
    assert db.get_channel(ch["id"])["last_error_code"] == "LOGIN_REQUIRED"
    events = db.list_events(run["id"], level="error")
    assert events and events[0]["event"] == "run_aborted"


def test_stop_event_cancels(settings, db: Database):
    slug = "stop"
    ch = db.create_channel(slug, initial_pages=1)
    ids = list(range(100, 90, -1))
    pages = {f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, ids))}
    for i in ids:
        pages[f"https://arca.live/b/{slug}/{i}"] = (200, article_html(slug, i, images=0))
    stop = threading.Event()
    http = FakeFetcher("http", pages)
    original = http.fetch_page

    def fetch_and_stop(url):
        result = original(url)
        if url.endswith("/98"):
            stop.set()
        return result

    http.fetch_page = fetch_and_stop  # type: ignore[assignment]
    run = run_channel(settings, db, ch["id"], "manual", stop_event=stop, fetcher_factory=make_factory(http, None))
    assert run["status"] == "cancelled" and run["code"] == "CANCELLED"
    assert 0 < run["stats"]["collected"] < len(ids)
    assert db.count_articles_by_state(ch["id"]).get("discovered", 0) > 0


def test_media_per_article_limit_defers_rest(settings, db: Database):
    settings.media.max_files_per_article_per_run = 2
    slug = "many"
    ch = db.create_channel(slug, initial_pages=1)
    pages = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [9])),
        f"https://arca.live/b/{slug}/9": (200, article_html(slug, 9, images=5)),
    }
    downloads = {f"https://ac-o.arca.live/2026/9_{n}.png": (200, PNG, "image/png") for n in range(5)}
    http = FakeFetcher("http", pages, downloads)
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    st = run["stats"]
    assert st["media_downloaded"] == 2 and st["media_deferred"] == 3
    assert run["status"] == "partial"
    assert '이월' in run['message'] and '실패' not in run['message']
    assert db.count_media_by_state(ch["id"]) == {"downloaded": 2, "pending": 3}
    # 다음 실행: 목록에 새 글 없음 → recheck 단계에서 pending 미디어가 남은 글을 다시 열어 이어받음
    settings.media.max_files_per_article_per_run = 10
    http2 = FakeFetcher("http", pages, downloads)
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http2, None))
    assert run2["stats"]["media_downloaded"] == 3 and run2["stats"]["rechecked"] == 1
    assert run2["status"] == "success"
    assert db.count_media_by_state(ch["id"]) == {"downloaded": 5}


def test_lock_conflict_leaves_no_run_record(settings, db: Database):
    from arca_archive.common import AppError, RunLock
    import pytest

    ch = db.create_channel("locked", initial_pages=1)
    holder = RunLock(settings.lock_path)
    assert holder.acquire()
    try:
        with pytest.raises(AppError) as exc:
            run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(FakeFetcher("http", {}), None))
        assert exc.value.code == "ALREADY_RUNNING"
        assert db.list_runs(5) == []
    finally:
        holder.release()


def test_original_fallback_then_upgrade_on_next_run(settings, db: Database):
    """원본이 일시 실패하면 변환본을 받고(is_original=0), 다음 실행에서 원본으로 승격한다."""
    slug = "orig"
    ch = db.create_channel(slug, initial_pages=1)
    pages = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [11])),
        f"https://arca.live/b/{slug}/11": (200, article_html(slug, 11, images=1)),
    }
    WEBP = b"RIFF\x00\x00\x00\x00WEBPVP8 " + b"\x00" * 32
    # 1차: 원본 후보(ac-o, ac+type=orig) 모두 네트워크 오류 → 변환본(webp)으로 저장
    http = FakeFetcher("http", pages, {f"https://ac.arca.live/2026/11_0.png": (200, WEBP, "image/webp")})
    original_download = http.download

    def flaky(url, referer, max_bytes):
        if "type=orig" in url:
            raise AppError("NETWORK_ERROR", "timeout")
        return original_download(url, referer, max_bytes)

    http.download = flaky  # type: ignore[assignment]
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    m = db.list_media(11)[0]
    assert run["status"] == "success"
    assert m["state"] == "downloaded" and m["is_original"] == 0 and m["original_unavailable"] == 0 and m["upgrade_attempts"] == 0  # 연결 오류는 횟수 미소모
    assert m["file_path"].endswith(".webp")
    old_path = Path(m["file_path"])
    events = [e["event"] for e in db.list_events(run["id"])]
    assert "media_fallback" in events
    # 2차: 원본 성공 → 파일 교체, 옛 변환본 삭제
    http2 = FakeFetcher("http", pages, {
        f"https://ac-o.arca.live/2026/11_0.png": (200, PNG, "image/png"),
        f"https://ac.arca.live/2026/11_0.png": (200, WEBP, "image/webp"),
    })
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http2, None))
    m = db.list_media(11)[0]
    assert run2["stats"]["media_upgraded"] == 1 and run2["stats"]["rechecked"] == 1
    assert m["is_original"] == 1 and m["file_path"].endswith(".png") and Path(m["file_path"]).read_bytes() == PNG
    assert not old_path.exists()
    # 3차: 더 이상 승격 대상이 아님
    http3 = FakeFetcher("http", pages)
    run3 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http3, None))
    assert run3["stats"]["rechecked"] == 0 and run3["status"] == "success"


def test_original_403_marks_unavailable_and_stops_retrying(settings, db: Database):
    slug = "noorig"
    ch = db.create_channel(slug, initial_pages=1)
    pages = {
        f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [12])),
        f"https://arca.live/b/{slug}/12": (200, article_html(slug, 12, images=1)),
    }
    downloads = {
        f"https://ac-o.arca.live/2026/12_0.png": (403, b"<xml/>", "application/xml"),
        f"https://ac.arca.live/2026/12_0.png": (200, JPG, "image/jpeg"),
    }
    http = FakeFetcher("http", pages, downloads)
    run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    m = db.list_media(12)[0]
    assert m["state"] == "downloaded" and m["is_original"] == 0 and m["original_unavailable"] == 1
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(FakeFetcher("http", pages, downloads), None))
    assert run2["stats"]["rechecked"] == 0


def test_emoticon_only_article_is_archived(settings, db: Database):
    slug = "emo"
    ch = db.create_channel(slug, initial_pages=1)
    body = ('<img class="arca-emoticon" data-store-id="1" src="//ac.arca.live/2026/emo.png?expires=9999999999&key=k" width="100" height="100" '
            'data-originalurl="https://ac-o.arca.live/2026/emo.png?expires=9999999999&key=k&type=orig">')
    html = article_html(slug, 13, body=body, images=0)
    pages = {f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [13])), f"https://arca.live/b/{slug}/13": (200, html)}
    http = FakeFetcher("http", pages, {f"https://ac-o.arca.live/2026/emo.png": (200, PNG, "image/png")})
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(http, None))
    a = db.get_article(13)
    media = db.list_media(13)
    assert run["stats"]["media_downloaded"] == 1
    assert a["body_text"] == "" and a["media_total"] == 1 and a["media_done"] == 1
    assert media[0]["kind"] == "emoticon" and media[0]["is_original"] == 1


def test_gif_detected_by_extension_without_data_orig():
    from lxml import html as lxml_html

    from arca_archive.parsers.article_page import extract_media

    node = lxml_html.fromstring('<div><video src="//ac.arca.live/a/anim.gif?expires=1&key=k"></video>'
                                '<video src="//ac.arca.live/a/clip.mp4?expires=1&key=k"></video></div>')
    kinds = [m.kind for m in extract_media(node, ["ac.arca.live"])]
    assert kinds == ["gif", "video"]


def test_media_schema_migration_v1_to_v2(tmp_path):
    import sqlite3

    from arca_archive.db import Database

    path = tmp_path / "old.sqlite3"
    conn = sqlite3.connect(path)
    conn.executescript("""
        CREATE TABLE channels (id INTEGER PRIMARY KEY, slug TEXT, created_at TEXT, updated_at TEXT);
        CREATE TABLE articles (id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL, url TEXT, discovered_at TEXT);
        CREATE TABLE comments (id INTEGER PRIMARY KEY, article_id INTEGER NOT NULL, captured_at TEXT);
        INSERT INTO articles (id, channel_id, url, discovered_at) VALUES (55, 1, 'u', 'now');
        CREATE TABLE media (id INTEGER PRIMARY KEY AUTOINCREMENT, article_id INTEGER NOT NULL, seq INTEGER NOT NULL,
          kind TEXT NOT NULL, origin TEXT NOT NULL DEFAULT 'body', source_key TEXT NOT NULL, served_url TEXT, original_url TEXT,
          poster_url TEXT, url_expires_at TEXT, width INTEGER, height INTEGER, file_path TEXT, file_size INTEGER, sha256 TEXT,
          content_type TEXT, state TEXT NOT NULL DEFAULT 'pending', state_code TEXT, state_message TEXT,
          attempts INTEGER NOT NULL DEFAULT 0, next_retry_at TEXT, created_at TEXT NOT NULL, downloaded_at TEXT);
        INSERT INTO media (article_id, seq, kind, source_key, created_at) VALUES (1, 1, 'image', 'k', 'now');
        PRAGMA user_version=1;
    """)
    conn.commit(); conn.close()
    db = Database(path)
    cols = {r[1] for r in db.connect().execute("PRAGMA table_info(media)").fetchall()}
    assert {"is_original", "original_unavailable", "upgrade_attempts"} <= cols
    assert db.connect().execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert "backfill_pages" in {r[1] for r in db.connect().execute("PRAGMA table_info(channels)").fetchall()}
    assert tuple(db.connect().execute("SELECT original_unavailable, upgrade_attempts FROM media").fetchone()) == (0, 0)
    assert db.connect().execute("SELECT remote_id FROM articles WHERE id=55").fetchone()[0] == "55"  # v4 백필
    db.close()


def test_login_state_observed_from_list_page(settings, db: Database):
    slug = "obs"
    ch = db.create_channel(slug, initial_pages=1, fetch_mode="browser")
    logged_out_list = list_html(slug, [5]).replace('<a href="/u/logout">x</a>', '<a href="/u/login">login</a>')
    browser = FakeFetcher("browser", {f"https://arca.live/b/{slug}?p=1": (200, logged_out_list),
                                      f"https://arca.live/b/{slug}/5": (200, article_html(slug, 5, images=0))})
    run = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(None, browser))
    assert run["status"] == "success" and run["stats"]["logged_in"] is False
    browser2 = FakeFetcher("browser", {f"https://arca.live/b/{slug}?p=1": (200, list_html(slug, [5]))})
    run2 = run_channel(settings, db, ch["id"], "manual", fetcher_factory=make_factory(None, browser2))
    assert run2["stats"]["logged_in"] is True
